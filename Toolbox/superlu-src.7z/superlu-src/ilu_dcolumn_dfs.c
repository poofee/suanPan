#include "slu_ddefs.h"
int
ilu_dcolumn_dfs(
	   const int  m,	  
	   const int  jcol,	  
	   int	      *perm_r,	  
	   int	      *nseg,	  
	   int	      *lsub_col,  
	   int	      *segrep,	  
	   int	      *repfnz,	  
	   int	      *marker,	  
	   int	      *parent,	  
	   int	      *xplore,	  
	   GlobalLU_t *Glu	  
	   )
{
    int     jcolp1, jcolm1, jsuper, nsuper, nextl;
    int     k, krep, krow, kmark, kperm;
    int     *marker2;		 
    int     fsupc;		 
    int     myfnz;		 
    int     chperm, chmark, chrep, kchild;
    int     xdfs, maxdfs, kpar, oldrep;
    int     jptr, jm1ptr;
    int     ito, ifrom; 	 
    int     mem_error;
    int     *xsup, *supno, *lsub, *xlsub;
    int     nzlmax;
    int     maxsuper;
    xsup    = Glu->xsup;
    supno   = Glu->supno;
    lsub    = Glu->lsub;
    xlsub   = Glu->xlsub;
    nzlmax  = Glu->nzlmax;
    maxsuper = sp_ienv(7);
    jcolp1  = jcol + 1;
    jcolm1  = jcol - 1;
    nsuper  = supno[jcol];
    jsuper  = nsuper;
    nextl   = xlsub[jcol];
    marker2 = &marker[2*m];
    for (k = 0; lsub_col[k] != EMPTY; k++) {
	krow = lsub_col[k];
	lsub_col[k] = EMPTY;
	kmark = marker2[krow];
	if ( kmark == jcol ) continue;
	marker2[krow] = jcol;
	kperm = perm_r[krow];
	if ( kperm == EMPTY ) {
	    lsub[nextl++] = krow;	 
	    if ( nextl >= nzlmax ) {
		if ((mem_error = dLUMemXpand(jcol, nextl, LSUB, &nzlmax, Glu)))
		    return (mem_error);
		lsub = Glu->lsub;
	    }
	    if ( kmark != jcolm1 ) jsuper = EMPTY; 
	} else {
	    krep = xsup[supno[kperm]+1] - 1;
	    myfnz = repfnz[krep];
	    if ( myfnz != EMPTY ) {	 
		if ( myfnz > kperm ) repfnz[krep] = kperm;
	    }
	    else {
		oldrep = EMPTY;
		parent[krep] = oldrep;
		repfnz[krep] = kperm;
		xdfs = xlsub[xsup[supno[krep]]];
		maxdfs = xlsub[krep + 1];
		do {
		    while ( xdfs < maxdfs ) {
			kchild = lsub[xdfs];
			xdfs++;
			chmark = marker2[kchild];
			if ( chmark != jcol ) {  
			    marker2[kchild] = jcol;
			    chperm = perm_r[kchild];
			    if ( chperm == EMPTY ) {
				lsub[nextl++] = kchild;
				if ( nextl >= nzlmax ) {
				    if ( (mem_error = dLUMemXpand(jcol,nextl,
					    LSUB,&nzlmax,Glu)) )
					return (mem_error);
				    lsub = Glu->lsub;
				}
				if ( chmark != jcolm1 ) jsuper = EMPTY;
			    } else {
				chrep = xsup[supno[chperm]+1] - 1;
				myfnz = repfnz[chrep];
				if ( myfnz != EMPTY ) {  
				    if ( myfnz > chperm )
					repfnz[chrep] = chperm;
				} else {
				    xplore[krep] = xdfs;
				    oldrep = krep;
				    krep = chrep;  
				    parent[krep] = oldrep;
				    repfnz[krep] = chperm;
				    xdfs = xlsub[xsup[supno[krep]]];
				    maxdfs = xlsub[krep + 1];
				}  
			   }  
			}  
		    }  
		    segrep[*nseg] = krep;
		    ++(*nseg);
		    kpar = parent[krep];  
		    if ( kpar == EMPTY ) break;  
		    krep = kpar;
		    xdfs = xplore[krep];
		    maxdfs = xlsub[krep + 1];
		} while ( kpar != EMPTY );	 
	    }  
	}  
    }  
    if ( jcol == 0 ) {  
	nsuper = supno[0] = 0;
    } else {
	fsupc = xsup[nsuper];
	jptr = xlsub[jcol];	 
	jm1ptr = xlsub[jcolm1];
	if ( (nextl-jptr != jptr-jm1ptr-1) ) jsuper = EMPTY;
	if ( nextl == jptr ) jsuper = EMPTY;
	if ( jcol - fsupc >= maxsuper ) jsuper = EMPTY;
	if ( jsuper == EMPTY ) {	 
	    if ( (fsupc < jcolm1) ) {  
#ifdef CHK_COMPRESS
		printf("  Compress lsub[] at super %d-%d\n", fsupc, jcolm1);
#endif
		ito = xlsub[fsupc+1];
		xlsub[jcolm1] = ito;
		xlsub[jcol] = ito;
		for (ifrom = jptr; ifrom < nextl; ++ifrom, ++ito)
		    lsub[ito] = lsub[ifrom];
		nextl = ito;
	    }
	    nsuper++;
	    supno[jcol] = nsuper;
	}  
    }	 
    xsup[nsuper+1] = jcolp1;
    supno[jcolp1]  = nsuper;
    xlsub[jcolp1]  = nextl;
    return 0;
}