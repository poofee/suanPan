#include <math.h>
#include <stdlib.h>
#include "slu_ddefs.h"
#ifndef SGN
#define SGN(x) ((x)>=0?1:-1)
#endif
int
ilu_dpivotL(
	const int  jcol,      
	const double u,       
	int	   *usepr,    
	int	   *perm_r,   
	int	   diagind,   
	int	   *swap,     
	int	   *iswap,    
	int	   *marker,   
	int	   *pivrow,   
	double	   fill_tol,  
	milu_t	   milu,      
	double	   drop_sum,  
	GlobalLU_t *Glu,      
	SuperLUStat_t *stat   
       )
{
    int		 n;	  
    int		 fsupc;   
    int		 nsupc;   
    int		 nsupr;   
    int		 lptr;	  
    register int	 pivptr;
    int		 old_pivptr, diag, ptr0;
    register double  pivmax, rtemp;
    double	 thresh;
    double	 temp;
    double	 *lu_sup_ptr;
    double	 *lu_col_ptr;
    int		 *lsub_ptr;
    register int	 isub, icol, k, itemp;
    int		 *lsub, *xlsub;
    double	 *lusup;
    int		 *xlusup;
    flops_t	 *ops = stat->ops;
    int		 info;
    n	       = Glu->n;
    lsub       = Glu->lsub;
    xlsub      = Glu->xlsub;
    lusup      = (double *) Glu->lusup;
    xlusup     = Glu->xlusup;
    fsupc      = (Glu->xsup)[(Glu->supno)[jcol]];
    nsupc      = jcol - fsupc;		 
    lptr       = xlsub[fsupc];
    nsupr      = xlsub[fsupc+1] - lptr;
    lu_sup_ptr = &lusup[xlusup[fsupc]];  
    lu_col_ptr = &lusup[xlusup[jcol]];	 
    lsub_ptr   = &lsub[lptr];	 
    pivmax = -1.0;
    pivptr = nsupc;
    diag = EMPTY;
    old_pivptr = nsupc;
    ptr0 = EMPTY;
    for (isub = nsupc; isub < nsupr; ++isub) {
        if (marker[lsub_ptr[isub]] > jcol)
            continue;  
	switch (milu) {
	    case SMILU_1:
		rtemp = fabs(lu_col_ptr[isub] + drop_sum);
		break;
	    case SMILU_2:
	    case SMILU_3:
		rtemp = fabs(lu_col_ptr[isub]);
		break;
	    case SILU:
	    default:
		rtemp = fabs(lu_col_ptr[isub]);
		break;
	}
	if (rtemp > pivmax) { pivmax = rtemp; pivptr = isub; }
	if (*usepr && lsub_ptr[isub] == *pivrow) old_pivptr = isub;
	if (lsub_ptr[isub] == diagind) diag = isub;
	if (ptr0 == EMPTY) ptr0 = isub;
    }
    if (milu == SMILU_2 || milu == SMILU_3) pivmax += drop_sum;
    if (pivmax < 0.0) {
	fprintf(stderr, "[0]: jcol=%d, SINGULAR!!!\n", jcol);
	fflush(stderr);
	exit(1);
    }
    if ( pivmax == 0.0 ) {
	if (diag != EMPTY)
	    *pivrow = lsub_ptr[pivptr = diag];
	else if (ptr0 != EMPTY)
	    *pivrow = lsub_ptr[pivptr = ptr0];
	else {
	    for (icol = jcol; icol < n; icol++)
		if (marker[swap[icol]] <= jcol) break;
	    if (icol >= n) {
		fprintf(stderr, "[1]: jcol=%d, SINGULAR!!!\n", jcol);
		fflush(stderr);
		exit(1);
	    }
	    *pivrow = swap[icol];
	    for (isub = nsupc; isub < nsupr; ++isub)
		if ( lsub_ptr[isub] == *pivrow ) { pivptr = isub; break; }
	}
	pivmax = fill_tol;
	lu_col_ptr[pivptr] = pivmax;
	*usepr = 0;
#ifdef DEBUG
	printf("[0] ZERO PIVOT: FILL (%d, %d).\n", *pivrow, jcol);
	fflush(stdout);
#endif
	info =jcol + 1;
    }  
    else {
	thresh = u * pivmax;
	if ( *usepr ) {
	    switch (milu) {
		case SMILU_1:
		    rtemp = fabs(lu_col_ptr[old_pivptr] + drop_sum);
		    break;
		case SMILU_2:
		case SMILU_3:
		    rtemp = fabs(lu_col_ptr[old_pivptr]) + drop_sum;
		    break;
		case SILU:
		default:
		    rtemp = fabs(lu_col_ptr[old_pivptr]);
		    break;
	    }
	    if ( rtemp != 0.0 && rtemp >= thresh ) pivptr = old_pivptr;
	    else *usepr = 0;
	}
	if ( *usepr == 0 ) {
	    if ( diag >= 0 ) {  
		switch (milu) {
		    case SMILU_1:
			rtemp = fabs(lu_col_ptr[diag] + drop_sum);
			break;
		    case SMILU_2:
		    case SMILU_3:
			rtemp = fabs(lu_col_ptr[diag]) + drop_sum;
			break;
		    case SILU:
		    default:
			rtemp = fabs(lu_col_ptr[diag]);
			break;
		}
		if ( rtemp != 0.0 && rtemp >= thresh ) pivptr = diag;
	    }
	    *pivrow = lsub_ptr[pivptr];
	}
	info = 0;
	switch (milu) {
	    case SMILU_1:
		lu_col_ptr[pivptr] += drop_sum;
		break;
	    case SMILU_2:
	    case SMILU_3:
		lu_col_ptr[pivptr] += SGN(lu_col_ptr[pivptr]) * drop_sum;
		break;
	    case SILU:
	    default:
		break;
	}
    }  
    perm_r[*pivrow] = jcol;
    if (jcol < n - 1) {
	register int t1, t2, t;
	t1 = iswap[*pivrow]; t2 = jcol;
	if (t1 != t2) {
	    t = swap[t1]; swap[t1] = swap[t2]; swap[t2] = t;
	    t1 = swap[t1]; t2 = t;
	    t = iswap[t1]; iswap[t1] = iswap[t2]; iswap[t2] = t;
	}
    }  
    if ( pivptr != nsupc ) {
	itemp = lsub_ptr[pivptr];
	lsub_ptr[pivptr] = lsub_ptr[nsupc];
	lsub_ptr[nsupc] = itemp;
	for (icol = 0; icol <= nsupc; icol++) {
	    itemp = pivptr + icol * nsupr;
	    temp = lu_sup_ptr[itemp];
	    lu_sup_ptr[itemp] = lu_sup_ptr[nsupc + icol*nsupr];
	    lu_sup_ptr[nsupc + icol*nsupr] = temp;
	}
    }  
    ops[FACT] += nsupr - nsupc;
    temp = 1.0 / lu_col_ptr[nsupc];
    for (k = nsupc+1; k < nsupr; k++) lu_col_ptr[k] *= temp;
    return info;
}