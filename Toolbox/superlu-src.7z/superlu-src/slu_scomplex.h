#ifndef __SUPERLU_SCOMPLEX  
#define __SUPERLU_SCOMPLEX
#ifndef SCOMPLEX_INCLUDE
#define SCOMPLEX_INCLUDE
typedef struct { float r, i; } complex;
#define c_add(c, a, b) { (c)->r = (a)->r + (b)->r; \
			 (c)->i = (a)->i + (b)->i; }
#define c_sub(c, a, b) { (c)->r = (a)->r - (b)->r; \
			 (c)->i = (a)->i - (b)->i; }
#define cs_mult(c, a, b) { (c)->r = (a)->r * (b); \
                           (c)->i = (a)->i * (b); }
#define cc_mult(c, a, b) { \
	float cr, ci; \
    	cr = (a)->r * (b)->r - (a)->i * (b)->i; \
    	ci = (a)->i * (b)->r + (a)->r * (b)->i; \
    	(c)->r = cr; \
    	(c)->i = ci; \
    }
#define cc_conj(a, b) { \
        (a)->r = (b)->r; \
        (a)->i = -((b)->i); \
    }
#define c_eq(a, b)  ( (a)->r == (b)->r && (a)->i == (b)->i )
#ifdef __cplusplus
extern "C" {
#endif
void c_div(complex *, complex *, complex *);
double c_abs(complex *);      
double c_abs1(complex *);     
void c_exp(complex *, complex *);
void r_cnjg(complex *, complex *);
double r_imag(complex *);
complex c_sgn(complex *);
complex c_sqrt(complex *);
#ifdef __cplusplus
  }
#endif
#endif
#endif   