#include <math.h>
#include "slu_Cnames.h"
#include "slu_dcomplex.h"
int
zlacon_(int *n, doublecomplex *v, doublecomplex *x, double *est, int *kase)
{
    int c__1 = 1;
    doublecomplex      zero = {0.0, 0.0};
    doublecomplex      one = {1.0, 0.0};
    double d__1;
    static int jump;
    int jlast;
     int iter;
     double altsgn, estold;
     int i, j;
    double temp;
    double safmin;
    extern double dlamch_(char *);
    extern int izmax1_slu(int *, doublecomplex *, int *);
    extern double dzsum1_slu(int *, doublecomplex *, int *);
    safmin = dlamch_("Safe minimum");
    if ( *kase == 0 ) {
	for (i = 0; i < *n; ++i) {
	    x[i].r = 1. / (double) (*n);
	    x[i].i = 0.;
	}
	*kase = 1;
	jump = 1;
	return 0;
    }
    switch (jump) {
	case 1:  goto L20;
	case 2:  goto L40;
	case 3:  goto L70;
	case 4:  goto L110;
	case 5:  goto L140;
    }
  L20:
    if (*n == 1) {
	v[0] = x[0];
	*est = z_abs(&v[0]);
	goto L150;
    }
    *est = dzsum1_slu(n, x, &c__1);
    for (i = 0; i < *n; ++i) {
	d__1 = z_abs(&x[i]);
	if (d__1 > safmin) {
	    d__1 = 1 / d__1;
	    x[i].r *= d__1;
	    x[i].i *= d__1;
	} else {
	    x[i] = one;
	}
    }
    *kase = 2;
    jump = 2;
    return 0;
L40:
    j = izmax1_slu(n, &x[0], &c__1);
    --j;
    iter = 2;
L50:
    for (i = 0; i < *n; ++i) x[i] = zero;
    x[j] = one;
    *kase = 1;
    jump = 3;
    return 0;
L70:
#ifdef _CRAY
    CCOPY(n, x, &c__1, v, &c__1);
#else
    zcopy_(n, x, &c__1, v, &c__1);
#endif
    estold = *est;
    *est = dzsum1_slu(n, v, &c__1);
L90:
    if (*est <= estold) goto L120;
    for (i = 0; i < *n; ++i) {
	d__1 = z_abs(&x[i]);
	if (d__1 > safmin) {
	    d__1 = 1 / d__1;
	    x[i].r *= d__1;
	    x[i].i *= d__1;
	} else {
	    x[i] = one;
	}
    }
    *kase = 2;
    jump = 4;
    return 0;
L110:
    jlast = j;
    j = izmax1_slu(n, &x[0], &c__1);
    --j;
    if (x[jlast].r != (d__1 = x[j].r, fabs(d__1)) && iter < 5) {
	++iter;
	goto L50;
    }
L120:
    altsgn = 1.;
    for (i = 1; i <= *n; ++i) {
	x[i-1].r = altsgn * ((double)(i - 1) / (double)(*n - 1) + 1.);
	x[i-1].i = 0.;
	altsgn = -altsgn;
    }
    *kase = 1;
    jump = 5;
    return 0;
L140:
    temp = dzsum1_slu(n, x, &c__1) / (double)(*n * 3) * 2.;
    if (temp > *est) {
#ifdef _CRAY
	CCOPY(n, &x[0], &c__1, &v[0], &c__1);
#else
	zcopy_(n, &x[0], &c__1, &v[0], &c__1);
#endif
	*est = temp;
    }
L150:
    *kase = 0;
    return 0;
}  