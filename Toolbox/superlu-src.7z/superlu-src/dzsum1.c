#include "slu_dcomplex.h"
#include "slu_Cnames.h"
double dzsum1_slu(int *n, doublecomplex *cx, int *incx)
{
    double z_abs(doublecomplex *);
    int i, nincx;
    double stemp;
#define CX(I) cx[(I)-1]
    stemp = 0.;
    if (*n <= 0) {
	return stemp;
    }
    if (*incx == 1) {
	goto L20;
    }
    nincx = *n * *incx;
    for (i = 1; *incx < 0 ? i >= nincx : i <= nincx; i += *incx) {
	stemp += z_abs(&CX(i));
    }
    return stemp;
L20:
    for (i = 1; i <= *n; ++i) {
	stemp += z_abs(&CX(i));
    }
    return stemp;
}  