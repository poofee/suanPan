#ifdef SUN 
#include <sys/time.h>
double SuperLU_timer_() {
    return ( (double)gethrtime() / 1e9 );
}
#elif _WIN32
#include <time.h>
double SuperLU_timer_()
{
    clock_t t;
    t=clock();
    return ((double)t)/CLOCKS_PER_SEC;
}
#else
#ifndef NO_TIMER
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>
#include <unistd.h>
#endif
double SuperLU_timer_()
{
#ifdef NO_TIMER
    double tmp;
    tmp = 0.0;
    return 0.0;
#else
    struct tms use;
    double tmp;
    int clocks_per_sec = sysconf(_SC_CLK_TCK);
    times ( &use );
    tmp = use.tms_utime;
    tmp += use.tms_stime;
    return (double)(tmp) / clocks_per_sec;
#endif
}
#endif