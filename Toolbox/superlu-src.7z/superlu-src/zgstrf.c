#include "slu_zdefs.h"
void
zgstrf (superlu_options_t *options, SuperMatrix *A,
        int relax, int panel_size, int *etree, void *work, int lwork,
        int *perm_c, int *perm_r, SuperMatrix *L, SuperMatrix *U,
    	GlobalLU_t *Glu,  
        SuperLUStat_t *stat, int *info)
{
    NCPformat *Astore;
    int       *iperm_r = NULL;  
    int       *iperm_c;  
    int       *iwork;
    doublecomplex    *zwork;
    int	      *segrep, *repfnz, *parent, *xplore;
    int	      *panel_lsub;  
    int	      *xprune;
    int	      *marker;
    doublecomplex    *dense, *tempv;
    int       *relax_end;
    doublecomplex    *a;
    int       *asub;
    int       *xa_begin, *xa_end;
    int       *xsup, *supno;
    int       *xlsub, *xlusup, *xusub;
    int       nzlumax;
    double fill_ratio = sp_ienv(6);   
    fact_t    fact = options->Fact;
    double    diag_pivot_thresh = options->DiagPivotThresh;
    int       pivrow;    
    int       nseg1;	 
    int       nseg;	 
    register int jcol;	
    register int kcol;	 
    register int icol;
    register int i, k, jj, new_next, iinfo;
    int       m, n, min_mn, jsupno, fsupc, nextlu, nextu;
    int       w_def;	 
    int       usepr, iperm_r_allocated = 0;
    int       nnzL, nnzU;
    int       *panel_histo = stat->panel_histo;
    flops_t   *ops = stat->ops;
    iinfo    = 0;
    m        = A->nrow;
    n        = A->ncol;
    min_mn   = SUPERLU_MIN(m, n);
    Astore   = A->Store;
    a        = Astore->nzval;
    asub     = Astore->rowind;
    xa_begin = Astore->colbeg;
    xa_end   = Astore->colend;
    *info = zLUMemInit(fact, work, lwork, m, n, Astore->nnz,
                       panel_size, fill_ratio, L, U, Glu, &iwork, &zwork);
    if ( *info ) return;
    xsup    = Glu->xsup;
    supno   = Glu->supno;
    xlsub   = Glu->xlsub;
    xlusup  = Glu->xlusup;
    xusub   = Glu->xusub;
    SetIWork(m, n, panel_size, iwork, &segrep, &parent, &xplore,
	     &repfnz, &panel_lsub, &xprune, &marker);
    zSetRWork(m, panel_size, zwork, &dense, &tempv);
    usepr = (fact == SamePattern_SameRowPerm);
    if ( usepr ) {
	iperm_r = (int *) intMalloc(m);
	for (k = 0; k < m; ++k) iperm_r[perm_r[k]] = k;
	iperm_r_allocated = 1;
    }
    iperm_c = (int *) intMalloc(n);
    for (k = 0; k < n; ++k) iperm_c[perm_c[k]] = k;
    relax_end = (int *) intMalloc(n);
    if ( options->SymmetricMode == YES ) {
        heap_relax_snode(n, etree, relax, marker, relax_end); 
    } else {
        relax_snode(n, etree, relax, marker, relax_end); 
    }
    ifill (perm_r, m, EMPTY);
    ifill (marker, m * NO_MARKER, EMPTY);
    supno[0] = -1;
    xsup[0]  = xlsub[0] = xusub[0] = xlusup[0] = 0;
    w_def    = panel_size;
    for (jcol = 0; jcol < min_mn; ) {
	if ( relax_end[jcol] != EMPTY ) {  
   	    kcol = relax_end[jcol];	   
	    panel_histo[kcol-jcol+1]++;
	    if ( (*info = zsnode_dfs(jcol, kcol, asub, xa_begin, xa_end,
				    xprune, marker, Glu)) != 0 )
		return;
            nextu    = xusub[jcol];
	    nextlu   = xlusup[jcol];
	    jsupno   = supno[jcol];
	    fsupc    = xsup[jsupno];
	    new_next = nextlu + (xlsub[fsupc+1]-xlsub[fsupc])*(kcol-jcol+1);
	    nzlumax = Glu->nzlumax;
	    while ( new_next > nzlumax ) {
		if ( (*info = zLUMemXpand(jcol, nextlu, LUSUP, &nzlumax, Glu)) )
		    return;
	    }
	    for (icol = jcol; icol<= kcol; icol++) {
		xusub[icol+1] = nextu;
    		for (k = xa_begin[icol]; k < xa_end[icol]; k++)
        	    dense[asub[k]] = a[k];
	        zsnode_bmod(icol, jsupno, fsupc, dense, tempv, Glu, stat);
		if ( (*info = zpivotL(icol, diag_pivot_thresh, &usepr, perm_r,
				      iperm_r, iperm_c, &pivrow, Glu, stat)) )
		    if ( iinfo == 0 ) iinfo = *info;
#ifdef DEBUG
		zprint_lu_col("[1]: ", icol, pivrow, xprune, Glu);
#endif
	    }
	    jcol = icol;
	} else {  
	    panel_size = w_def;
	    for (k = jcol + 1; k < SUPERLU_MIN(jcol+panel_size, min_mn); k++) 
		if ( relax_end[k] != EMPTY ) {
		    panel_size = k - jcol;
		    break;
		}
	    if ( k == min_mn ) panel_size = min_mn - jcol;
	    panel_histo[panel_size]++;
	    zpanel_dfs(m, panel_size, jcol, A, perm_r, &nseg1,
		      dense, panel_lsub, segrep, repfnz, xprune,
		      marker, parent, xplore, Glu);
	    zpanel_bmod(m, panel_size, jcol, nseg1, dense,
		        tempv, segrep, repfnz, Glu, stat);
    	    for ( jj = jcol; jj < jcol + panel_size; jj++) {
 		k = (jj - jcol) * m;  
		nseg = nseg1;	 
	    	if ((*info = zcolumn_dfs(m, jj, perm_r, &nseg, &panel_lsub[k],
					segrep, &repfnz[k], xprune, marker,
					parent, xplore, Glu)) != 0) return;
	    	if ((*info = zcolumn_bmod(jj, (nseg - nseg1), &dense[k],
					 tempv, &segrep[nseg1], &repfnz[k],
					 jcol, Glu, stat)) != 0) return;
		if ((*info = zcopy_to_ucol(jj, nseg, segrep, &repfnz[k],
					  perm_r, &dense[k], Glu)) != 0)
		    return;
	    	if ( (*info = zpivotL(jj, diag_pivot_thresh, &usepr, perm_r,
				      iperm_r, iperm_c, &pivrow, Glu, stat)) )
		    if ( iinfo == 0 ) iinfo = *info;
	    	zpruneL(jj, perm_r, pivrow, nseg, segrep,
                        &repfnz[k], xprune, Glu);
	    	resetrep_col (nseg, segrep, &repfnz[k]);
#ifdef DEBUG
		zprint_lu_col("[2]: ", jj, pivrow, xprune, Glu);
#endif
	    }
   	    jcol += panel_size;	 
	}  
    }  
    *info = iinfo;
    if ( m > n ) {
	k = 0;
        for (i = 0; i < m; ++i) 
            if ( perm_r[i] == EMPTY ) {
    		perm_r[i] = n + k;
		++k;
	    }
    }
    countnz(min_mn, xprune, &nnzL, &nnzU, Glu);
    fixupL(min_mn, perm_r, Glu);
    zLUWorkFree(iwork, zwork, Glu);  
    if ( fact == SamePattern_SameRowPerm ) {
        ((SCformat *)L->Store)->nnz = nnzL;
	((SCformat *)L->Store)->nsuper = Glu->supno[n];
	((SCformat *)L->Store)->nzval = (doublecomplex *) Glu->lusup;
	((SCformat *)L->Store)->nzval_colptr = Glu->xlusup;
	((SCformat *)L->Store)->rowind = Glu->lsub;
	((SCformat *)L->Store)->rowind_colptr = Glu->xlsub;
	((NCformat *)U->Store)->nnz = nnzU;
	((NCformat *)U->Store)->nzval = (doublecomplex *) Glu->ucol;
	((NCformat *)U->Store)->rowind = Glu->usub;
	((NCformat *)U->Store)->colptr = Glu->xusub;
    } else {
        zCreate_SuperNode_Matrix(L, A->nrow, min_mn, nnzL, 
	      (doublecomplex *) Glu->lusup, Glu->xlusup, 
              Glu->lsub, Glu->xlsub, Glu->supno, Glu->xsup,
              SLU_SC, SLU_Z, SLU_TRLU);
    	zCreate_CompCol_Matrix(U, min_mn, min_mn, nnzU, 
	      (doublecomplex *) Glu->ucol, Glu->usub, Glu->xusub,
              SLU_NC, SLU_Z, SLU_TRU);
    }
    ops[FACT] += ops[TRSV] + ops[GEMV];	
    stat->expansions = --(Glu->num_expansions);
    if ( iperm_r_allocated ) SUPERLU_FREE (iperm_r);
    SUPERLU_FREE (iperm_c);
    SUPERLU_FREE (relax_end);
}