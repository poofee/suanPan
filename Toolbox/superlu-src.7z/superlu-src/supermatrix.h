#ifndef __SUPERLU_SUPERMATRIX  
#define __SUPERLU_SUPERMATRIX
typedef enum {
    SLU_NC,     
    SLU_NCP,    
    SLU_NR,     
    SLU_SC,     
    SLU_SCP,        
    SLU_SR,     
    SLU_DN,      
    SLU_NR_loc    
} Stype_t;
typedef enum {
    SLU_S,      
    SLU_D,      
    SLU_C,      
    SLU_Z       
} Dtype_t;
typedef enum {
    SLU_GE,     
    SLU_TRLU,   
    SLU_TRUU,   
    SLU_TRL,    
    SLU_TRU,    
    SLU_SYL,    
    SLU_SYU,    
    SLU_HEL,    
    SLU_HEU     
} Mtype_t;
typedef struct {
	Stype_t Stype;  
	Dtype_t Dtype;  
	Mtype_t Mtype;  
	int_t  nrow;    
	int_t  ncol;    
	void *Store;    
} SuperMatrix;
typedef struct {
    int_t  nnz;	     
    void *nzval;     
    int_t  *rowind;  
    int_t  *colptr;  
} NCformat;
typedef struct {
    int_t  nnz;	     
    void *nzval;     
    int_t  *colind;  
    int_t  *rowptr;  
} NRformat;
typedef struct {
  int_t  nnz;	      
  int_t  nsuper;      
  void *nzval;        
  int_t *nzval_colptr; 
  int_t *rowind;      
  int_t *rowind_colptr; 
  int_t *col_to_sup;    
  int_t *sup_to_col;    
} SCformat;
typedef struct {
  int_t  nnz;	      
  int_t  nsuper;      
  void *nzval;        
  int_t  *nzval_colbeg; 
  int_t  *nzval_colend; 
  int_t  *rowind;       
  int_t *rowind_colbeg; 
  int_t *rowind_colend; 
  int_t *col_to_sup;    
  int_t *sup_to_colbeg;  
  int_t *sup_to_colend;  
} SCPformat;
typedef struct {
    int_t nnz;	   
    void *nzval;   
    int_t *rowind; 
    int_t *colbeg; 
    int_t *colend; 
} NCPformat;
typedef struct {
    int_t lda;     
    void *nzval;   
} DNformat;
typedef struct {
    int_t nnz_loc;    
    int_t m_loc;      
    int_t fst_row;    
    void  *nzval;     
    int_t *rowptr;    
    int_t *colind;    
} NRformat_loc;
#endif   