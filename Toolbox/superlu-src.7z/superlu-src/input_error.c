#include <stdio.h>
#include "slu_Cnames.h"
int input_error(char *srname, int *info)
{
    printf("** On entry to %6s, parameter number %2d had an illegal value\n",
		srname, *info);
    return 0;
}