#include <math.h>
#include "slu_scomplex.h"
#include "slu_Cnames.h"
int icmax1_slu(int *n, complex *cx, int *incx)
{
    int ret_val, i__1, i__2;
    float r__1;
    static float smax;
    static int i, ix;
#define CX(I) cx[(I)-1]
    ret_val = 0;
    if (*n < 1) {
	return ret_val;
    }
    ret_val = 1;
    if (*n == 1) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L30;
    }
    ix = 1;
    smax = (r__1 = CX(1).r, fabs(r__1));
    ix += *incx;
    i__1 = *n;
    for (i = 2; i <= *n; ++i) {
	i__2 = ix;
	if ((r__1 = CX(ix).r, fabs(r__1)) <= smax) {
	    goto L10;
	}
	ret_val = i;
	i__2 = ix;
	smax = (r__1 = CX(ix).r, fabs(r__1));
L10:
	ix += *incx;
    }
    return ret_val;
L30:
    smax = (r__1 = CX(1).r, fabs(r__1));
    i__1 = *n;
    for (i = 2; i <= *n; ++i) {
	i__2 = i;
	if ((r__1 = CX(i).r, fabs(r__1)) <= smax) {
	    goto L40;
	}
	ret_val = i;
	i__2 = i;
	smax = (r__1 = CX(i).r, fabs(r__1));
L40:
	;
    }
    return ret_val;
}  