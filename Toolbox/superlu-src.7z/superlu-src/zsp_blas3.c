#include "slu_zdefs.h"
int
sp_zgemm(char *transa, char *transb, int m, int n, int k, 
         doublecomplex alpha, SuperMatrix *A, doublecomplex *b, int ldb, 
         doublecomplex beta, doublecomplex *c, int ldc)
{
    int    incx = 1, incy = 1;
    int    j;
    for (j = 0; j < n; ++j) {
	sp_zgemv(transa, alpha, A, &b[ldb*j], incx, beta, &c[ldc*j], incy);
    }
    return 0;    
}