#include "slu_scomplex.h"
#include "slu_Cnames.h"
double scsum1_slu(int *n, complex *cx, int *incx)
{
    int i__1, i__2;
    float ret_val;
    double c_abs(complex *);
    static int i, nincx;
    static float stemp;
#define CX(I) cx[(I)-1]
    ret_val = 0.f;
    stemp = 0.f;
    if (*n <= 0) {
	return ret_val;
    }
    if (*incx == 1) {
	goto L20;
    }
    nincx = *n * *incx;
    i__1 = nincx;
    i__2 = *incx;
    for (i = 1; *incx < 0 ? i >= nincx : i <= nincx; i += *incx) {
	stemp += c_abs(&CX(i));
    }
    ret_val = stemp;
    return ret_val;
L20:
    i__2 = *n;
    for (i = 1; i <= *n; ++i) {
	stemp += c_abs(&CX(i));
    }
    ret_val = stemp;
    return ret_val;
}  