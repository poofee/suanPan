#ifndef __SUPERLU_UTIL  
#define __SUPERLU_UTIL
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "superlu_enum_consts.h"
#define SUPERLU_MAJOR_VERSION     5
#define SUPERLU_MINOR_VERSION     2
#define SUPERLU_PATCH_VERSION     1
#define FIRSTCOL_OF_SNODE(i)	(xsup[i])
#define NO_MARKER     3
#define NUM_TEMPV(m,w,t,b)  ( SUPERLU_MAX(m, (t + b)*w) )
#ifndef USER_ABORT
#define USER_ABORT(msg) superlu_abort_and_exit(msg)
#endif
#define ABORT(err_msg) \
 { char msg[256];\
   sprintf(msg,"%s at line %d in file %s\n",err_msg,__LINE__, __FILE__);\
   USER_ABORT(msg); }
#ifndef USER_MALLOC
#if 1
#define USER_MALLOC(size) superlu_malloc(size)
#else
#define USER_MALLOC(size) memset (superlu_malloc(size), '\x0F', size)
#endif
#endif
#define SUPERLU_MALLOC(size) USER_MALLOC(size)
#ifndef USER_FREE
#define USER_FREE(addr) superlu_free(addr)
#endif
#define SUPERLU_FREE(addr) USER_FREE(addr)
#define CHECK_MALLOC(where) {                 \
    extern int superlu_malloc_total;        \
    printf("%s: malloc_total %d Bytes\n",     \
	   where, superlu_malloc_total); \
}
#define SUPERLU_MAX(x, y) 	( (x) > (y) ? (x) : (y) )
#define SUPERLU_MIN(x, y) 	( (x) < (y) ? (x) : (y) )
#define L_SUB_START(col)     ( Lstore->rowind_colptr[col] )
#define L_SUB(ptr)           ( Lstore->rowind[ptr] )
#define L_NZ_START(col)      ( Lstore->nzval_colptr[col] )
#define L_FST_SUPC(superno)  ( Lstore->sup_to_col[superno] )
#define U_NZ_START(col)      ( Ustore->colptr[col] )
#define U_SUB(ptr)           ( Ustore->rowind[ptr] )
#define EMPTY	(-1)
#define FALSE	0
#define TRUE	1
#define NO_MEMTYPE  4       
#define GluIntArray(n)   (5 * (n) + 5)
#define  NODROP	        ( 0x0000 )
#define	 DROP_BASIC	( 0x0001 )   
#define  DROP_PROWS	( 0x0002 )   
#define  DROP_COLUMN	( 0x0004 )   
#define  DROP_AREA 	( 0x0008 )   
#define  DROP_SECONDARY	( 0x000E )   
#define  DROP_DYNAMIC	( 0x0010 )   
#define  DROP_INTERP	( 0x0100 )   
#if 1
#define MILU_ALPHA (1.0e-2)  
#else
#define MILU_ALPHA  1.0  
#endif
typedef float    flops_t;
typedef unsigned char Logical;
typedef struct {
    fact_t        Fact;
    yes_no_t      Equil;
    colperm_t     ColPerm;
    trans_t       Trans;
    IterRefine_t  IterRefine;
    double        DiagPivotThresh;
    yes_no_t      SymmetricMode;
    yes_no_t      PivotGrowth;
    yes_no_t      ConditionNumber;
    rowperm_t     RowPerm;
    int 	  ILU_DropRule;
    double	  ILU_DropTol;     
    double	  ILU_FillFactor;  
    norm_t	  ILU_Norm;        
    double	  ILU_FillTol;     
    milu_t	  ILU_MILU;
    double	  ILU_MILU_Dim;    
    yes_no_t      ParSymbFact;
    yes_no_t      ReplaceTinyPivot;  
    yes_no_t      SolveInitialized;
    yes_no_t      RefineInitialized;
    yes_no_t      PrintStat;
    int           nnzL, nnzU;       
    int           num_lookaheads;   
    yes_no_t      lookahead_etree;  
    yes_no_t      SymPattern;       
} superlu_options_t;
typedef struct e_node {
    int size;       
    void *mem;      
} ExpHeader;
typedef struct {
    int  size;
    int  used;
    int  top1;   
    int  top2;   
    void *array;
} LU_stack_t;
typedef struct {
    int     *panel_histo;  
    double  *utime;        
    flops_t *ops;          
    int     TinyPivots;    
    int     RefineSteps;   
    int     expansions;    
} SuperLUStat_t;
typedef struct {
    float for_lu;
    float total_needed;
} mem_usage_t;
typedef struct {
    int     *xsup;     
    int     *supno;   
    int     *lsub;     
    int	    *xlsub;
    void    *lusup;    
    int     *xlusup;
    void    *ucol;     
    int     *usub;
    int	    *xusub;
    int     nzlmax;    
    int     nzumax;    
    int     nzlumax;   
    int     n;         
    LU_space_t MemModel;  
    int     num_expansions;
    ExpHeader *expanders;  
    LU_stack_t stack;      
} GlobalLU_t;
#ifdef __cplusplus
extern "C" {
#endif
extern int     input_error(char *, int *);
extern void    Destroy_SuperMatrix_Store(SuperMatrix *);
extern void    Destroy_CompCol_Matrix(SuperMatrix *);
extern void    Destroy_CompRow_Matrix(SuperMatrix *);
extern void    Destroy_SuperNode_Matrix(SuperMatrix *);
extern void    Destroy_CompCol_Permuted(SuperMatrix *);
extern void    Destroy_Dense_Matrix(SuperMatrix *);
extern void    get_perm_c(int, SuperMatrix *, int *);
extern void    set_default_options(superlu_options_t *options);
extern void    ilu_set_default_options(superlu_options_t *options);
extern void    sp_preorder (superlu_options_t *, SuperMatrix*, int*, int*,
			    SuperMatrix*);
extern void    superlu_abort_and_exit(char*);
extern void    *superlu_malloc (size_t);
extern int     *intMalloc (int);
extern int     *intCalloc (int);
extern void    superlu_free (void*);
extern void    SetIWork (int, int, int, int *, int **, int **, int **,
                         int **, int **, int **, int **);
extern int     sp_coletree (int *, int *, int *, int, int, int *);
extern void    relax_snode (const int, int *, const int, int *, int *);
extern void    heap_relax_snode (const int, int *, const int, int *, int *);
extern int     mark_relax(int, int *, int *, int *, int *, int *, int *);
extern void    ilu_relax_snode (const int, int *, const int, int *,
				int *, int *);
extern void    ilu_heap_relax_snode (const int, int *, const int, int *,
				     int *, int*);
extern void    resetrep_col (const int, const int *, int *);
extern int     spcoletree (int *, int *, int *, int, int, int *);
extern int     *TreePostorder (int, int *);
extern double  SuperLU_timer_ ();
extern int     sp_ienv (int);
extern int     xerbla_ (char *, int *);
extern void    ifill (int *, int, int);
extern void    snode_profile (int, int *);
extern void    super_stats (int, int *);
extern void    check_repfnz(int, int, int, int *);
extern void    PrintSumm (char *, int, int, int);
extern void    StatInit(SuperLUStat_t *);
extern void    StatPrint (SuperLUStat_t *);
extern void    StatFree(SuperLUStat_t *);
extern void    print_panel_seg(int, int, int, int, int *, int *);
extern int     print_int_vec(char *,int, int *);
extern int     slu_PrintInt10(char *, int, int *);
#ifdef __cplusplus
  }
#endif
#endif  