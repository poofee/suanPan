#include "slu_ddefs.h"
void
relax_snode (
	     const     int n,
	     int       *et,            
	     const int relax_columns,  
	     int       *descendants,   
	     int       *relax_end      
	     )
{
    register int j, parent;
    register int snode_start;	 
    ifill (relax_end, n, EMPTY);
    for (j = 0; j < n; j++) descendants[j] = 0;
    for (j = 0; j < n; j++) {
	parent = et[j];
	if ( parent != n )   
	    descendants[parent] += descendants[j] + 1;
    }
    for (j = 0; j < n; ) { 
     	parent = et[j];
        snode_start = j;
 	while ( parent != n && descendants[parent] < relax_columns ) {
	    j = parent;
	    parent = et[j];
	}
	relax_end[snode_start] = j;		 
	j++;
	while ( descendants[j] != 0 && j < n ) j++;
    }
}