#ifndef COLAMD_H
#define COLAMD_H
#include <stdlib.h>
#define COLAMD_KNOBS 20
#define COLAMD_STATS 20
#define COLAMD_DENSE_ROW 0
#define COLAMD_DENSE_COL 1
#define COLAMD_DEFRAG_COUNT 2
#define COLAMD_STATUS 3
#define COLAMD_INFO1 4
#define COLAMD_INFO2 5
#define COLAMD_INFO3 6
#define COLAMD_OK				(0)
#define COLAMD_OK_BUT_JUMBLED			(1)
#define COLAMD_ERROR_A_not_present		(-1)
#define COLAMD_ERROR_p_not_present		(-2)
#define COLAMD_ERROR_nrow_negative		(-3)
#define COLAMD_ERROR_ncol_negative		(-4)
#define COLAMD_ERROR_nnz_negative		(-5)
#define COLAMD_ERROR_p0_nonzero			(-6)
#define COLAMD_ERROR_A_too_small		(-7)
#define COLAMD_ERROR_col_length_negative	(-8)
#define COLAMD_ERROR_row_index_out_of_bounds	(-9)
#define COLAMD_ERROR_out_of_memory		(-10)
#define COLAMD_ERROR_internal_error		(-999)
typedef struct Colamd_Col_struct
{
    int start ;		 
    int length ;	 
    union
    {
	int thickness ;	 
	int parent ;	 
    } shared1 ;
    union
    {
	int score ;	 
	int order ;	 
    } shared2 ;
    union
    {
	int headhash ;	 
	int hash ;	 
	int prev ;	 
    } shared3 ;
    union
    {
	int degree_next ;	 
	int hash_next ;		 
    } shared4 ;
} Colamd_Col ;
typedef struct Colamd_Row_struct
{
    int start ;		 
    int length ;	 
    union
    {
	int degree ;	 
	int p ;		 
    } shared1 ;
    union
    {
	int mark ;	 
	int first_column ; 
    } shared2 ;
} Colamd_Row ;
#define COLAMD_C(n_col) ((int) (((n_col) + 1) * sizeof (Colamd_Col) / sizeof (int)))
#define COLAMD_R(n_row) ((int) (((n_row) + 1) * sizeof (Colamd_Row) / sizeof (int)))
#define COLAMD_RECOMMENDED(nnz, n_row, n_col)                                 \
(                                                                             \
((nnz) < 0 || (n_row) < 0 || (n_col) < 0)                                     \
?                                                                             \
    (-1)                                                                      \
:                                                                             \
    (2 * (nnz) + COLAMD_C (n_col) + COLAMD_R (n_row) + (n_col) + ((nnz) / 5)) \
)
int colamd_recommended		 
(
    int nnz,			 
    int n_row,			 
    int n_col			 
) ;
void colamd_set_defaults	 
(				 
    double knobs [COLAMD_KNOBS]	 
) ;
int colamd			 
(				 
    int n_row,			 
    int n_col,			 
    int Alen,			 
    int A [],			 
    int p [],			 
    double knobs [COLAMD_KNOBS], 
    int stats [COLAMD_STATS]	 
) ;
int symamd				 
(
    int n,				 
    int A [],				 
    int p [],				 
    int perm [],			 
    double knobs [COLAMD_KNOBS],	 
    int stats [COLAMD_STATS],		 
    void * (*allocate) (size_t, size_t),
    void (*release) (void *)
) ;
void colamd_report
(
    int stats [COLAMD_STATS]
) ;
void symamd_report
(
    int stats [COLAMD_STATS]
) ;
#endif  