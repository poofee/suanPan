#include "slu_sdefs.h"
int
ssnode_dfs (
	   const int  jcol,	     
	   const int  kcol, 	     
	   const int  *asub,         
	   const int  *xa_begin,     
	   const int  *xa_end,       
	   int        *xprune,       
	   int        *marker,       
	   GlobalLU_t *Glu           
	   )
{
    register int i, k, ifrom, ito, nextl, new_next;
    int          nsuper, krow, kmark, mem_error;
    int          *xsup, *supno;
    int          *lsub, *xlsub;
    int          nzlmax;
    xsup    = Glu->xsup;
    supno   = Glu->supno;
    lsub    = Glu->lsub;
    xlsub   = Glu->xlsub;
    nzlmax  = Glu->nzlmax;
    nsuper = ++supno[jcol];	 
    nextl = xlsub[jcol];
    for (i = jcol; i <= kcol; i++) {
	for (k = xa_begin[i]; k < xa_end[i]; k++) {	
	    krow = asub[k];
	    kmark = marker[krow];
	    if ( kmark != kcol ) {  
		marker[krow] = kcol;
		lsub[nextl++] = krow;
		if ( nextl >= nzlmax ) {
		    if ( mem_error = sLUMemXpand(jcol, nextl, LSUB, &nzlmax, Glu) )
			return (mem_error);
		    lsub = Glu->lsub;
		}
	    }
    	}
	supno[i] = nsuper;
    }
    if ( jcol < kcol ) {
	new_next = nextl + (nextl - xlsub[jcol]);
	while ( new_next > nzlmax ) {
	    if ( mem_error = sLUMemXpand(jcol, nextl, LSUB, &nzlmax, Glu) )
		return (mem_error);
	    lsub = Glu->lsub;
	}
	ito = nextl;
	for (ifrom = xlsub[jcol]; ifrom < nextl; )
	    lsub[ito++] = lsub[ifrom++];	
        for (i = jcol+1; i <= kcol; i++) xlsub[i] = nextl;
	nextl = ito;
    }
    xsup[nsuper+1] = kcol + 1;
    supno[kcol+1]  = nsuper;
    xprune[kcol]   = nextl;
    xlsub[kcol+1]  = nextl;
    return 0;
}