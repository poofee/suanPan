#include "slu_ddefs.h"
#include "colamd.h"
extern int  genmmd_(int *, int *, int *, int *, int *, int *, int *, 
		    int *, int *, int *, int *, int *);
void
get_colamd(
	   const int m,   
	   const int n,   
	   const int nnz, 
	   int *colptr,   
	   int *rowind,   
	   int *perm_c    
	   )
{
    int Alen, *A, i, info, *p;
    double knobs[COLAMD_KNOBS];
    int stats[COLAMD_STATS];
    Alen = colamd_recommended(nnz, m, n);
    colamd_set_defaults(knobs);
    if (!(A = (int *) SUPERLU_MALLOC(Alen * sizeof(int))) )
        ABORT("Malloc fails for A[]");
    if (!(p = (int *) SUPERLU_MALLOC((n+1) * sizeof(int))) )
        ABORT("Malloc fails for p[]");
    for (i = 0; i <= n; ++i) p[i] = colptr[i];
    for (i = 0; i < nnz; ++i) A[i] = rowind[i];
    info = colamd(m, n, Alen, A, p, knobs, stats);
    if ( info == FALSE ) ABORT("COLAMD failed");
    for (i = 0; i < n; ++i) perm_c[p[i]] = i;
    SUPERLU_FREE(A);
    SUPERLU_FREE(p);
}
void
getata(
       const int m,       
       const int n,       
       const int nz,      
       int *colptr,       
       int *rowind,       
       int *atanz,        
       int **ata_colptr,  
       int **ata_rowind   
       )
{
    register int i, j, k, col, num_nz, ti, trow;
    int *marker, *b_colptr, *b_rowind;
    int *t_colptr, *t_rowind;  
    if ( !(marker = (int*) SUPERLU_MALLOC((SUPERLU_MAX(m,n)+1)*sizeof(int))) )
	ABORT("SUPERLU_MALLOC fails for marker[]");
    if ( !(t_colptr = (int*) SUPERLU_MALLOC((m+1) * sizeof(int))) )
	ABORT("SUPERLU_MALLOC t_colptr[]");
    if ( !(t_rowind = (int*) SUPERLU_MALLOC(nz * sizeof(int))) )
	ABORT("SUPERLU_MALLOC fails for t_rowind[]");
    for (i = 0; i < m; ++i) marker[i] = 0;
    for (j = 0; j < n; ++j) {
	for (i = colptr[j]; i < colptr[j+1]; ++i)
	    ++marker[rowind[i]];
    }
    t_colptr[0] = 0;
    for (i = 0; i < m; ++i) {
	t_colptr[i+1] = t_colptr[i] + marker[i];
	marker[i] = t_colptr[i];
    }
    for (j = 0; j < n; ++j)
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    col = rowind[i];
	    t_rowind[marker[col]] = j;
	    ++marker[col];
	}
    for (i = 0; i < n; ++i) marker[i] = -1;
    num_nz = 0;
    for (j = 0; j < n; ++j) {
	marker[j] = j;
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    k = rowind[i];
	    for (ti = t_colptr[k]; ti < t_colptr[k+1]; ++ti) {
		trow = t_rowind[ti];
		if ( marker[trow] != j ) {
		    marker[trow] = j;
		    num_nz++;
		}
	    }
	}
    }
    *atanz = num_nz;
    if ( !(*ata_colptr = (int*) SUPERLU_MALLOC( (n+1) * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails for ata_colptr[]");
    if ( *atanz ) {
	if ( !(*ata_rowind = (int*) SUPERLU_MALLOC( *atanz * sizeof(int)) ) )
	    ABORT("SUPERLU_MALLOC fails for ata_rowind[]");
    }
    b_colptr = *ata_colptr;  
    b_rowind = *ata_rowind;
    for (i = 0; i < n; ++i) marker[i] = -1;
    num_nz = 0;
    for (j = 0; j < n; ++j) {
	b_colptr[j] = num_nz;
	marker[j] = j;
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    k = rowind[i];
	    for (ti = t_colptr[k]; ti < t_colptr[k+1]; ++ti) {
		trow = t_rowind[ti];
		if ( marker[trow] != j ) {
		    marker[trow] = j;
		    b_rowind[num_nz++] = trow;
		}
	    }
	}
    }
    b_colptr[n] = num_nz;
    SUPERLU_FREE(marker);
    SUPERLU_FREE(t_colptr);
    SUPERLU_FREE(t_rowind);
}
void
at_plus_a(
	  const int n,       
	  const int nz,      
	  int *colptr,       
	  int *rowind,       
	  int *bnz,          
	  int **b_colptr,    
	  int **b_rowind     
	  )
{
    register int i, j, k, col, num_nz;
    int *t_colptr, *t_rowind;  
    int *marker;
    if ( !(marker = (int*) SUPERLU_MALLOC( n * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails for marker[]");
    if ( !(t_colptr = (int*) SUPERLU_MALLOC( (n+1) * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails for t_colptr[]");
    if ( !(t_rowind = (int*) SUPERLU_MALLOC( nz * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails t_rowind[]");
    for (i = 0; i < n; ++i) marker[i] = 0;
    for (j = 0; j < n; ++j) {
	for (i = colptr[j]; i < colptr[j+1]; ++i)
	    ++marker[rowind[i]];
    }
    t_colptr[0] = 0;
    for (i = 0; i < n; ++i) {
	t_colptr[i+1] = t_colptr[i] + marker[i];
	marker[i] = t_colptr[i];
    }
    for (j = 0; j < n; ++j)
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    col = rowind[i];
	    t_rowind[marker[col]] = j;
	    ++marker[col];
	}
    for (i = 0; i < n; ++i) marker[i] = -1;
    num_nz = 0;
    for (j = 0; j < n; ++j) {
	marker[j] = j;
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    k = rowind[i];
	    if ( marker[k] != j ) {
		marker[k] = j;
		++num_nz;
	    }
	}
	for (i = t_colptr[j]; i < t_colptr[j+1]; ++i) {
	    k = t_rowind[i];
	    if ( marker[k] != j ) {
		marker[k] = j;
		++num_nz;
	    }
	}
    }
    *bnz = num_nz;
    if ( !(*b_colptr = (int*) SUPERLU_MALLOC( (n+1) * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails for b_colptr[]");
    if ( *bnz) {
      if ( !(*b_rowind = (int*) SUPERLU_MALLOC( *bnz * sizeof(int)) ) )
	ABORT("SUPERLU_MALLOC fails for b_rowind[]");
    }
    for (i = 0; i < n; ++i) marker[i] = -1;
    num_nz = 0;
    for (j = 0; j < n; ++j) {
	(*b_colptr)[j] = num_nz;
	marker[j] = j;
	for (i = colptr[j]; i < colptr[j+1]; ++i) {
	    k = rowind[i];
	    if ( marker[k] != j ) {
		marker[k] = j;
		(*b_rowind)[num_nz++] = k;
	    }
	}
	for (i = t_colptr[j]; i < t_colptr[j+1]; ++i) {
	    k = t_rowind[i];
	    if ( marker[k] != j ) {
		marker[k] = j;
		(*b_rowind)[num_nz++] = k;
	    }
	}
    }
    (*b_colptr)[n] = num_nz;
    SUPERLU_FREE(marker);
    SUPERLU_FREE(t_colptr);
    SUPERLU_FREE(t_rowind);
}
void
get_perm_c(int ispec, SuperMatrix *A, int *perm_c)
{
    NCformat *Astore = A->Store;
    int m, n, bnz = 0, *b_colptr, i;
    int delta, maxint, nofsub, *invp;
    int *b_rowind, *dhead, *qsize, *llist, *marker;
    double t, SuperLU_timer_();
    m = A->nrow;
    n = A->ncol;
    t = SuperLU_timer_();
    switch ( ispec ) {
    case (NATURAL):  
	for (i = 0; i < n; ++i) perm_c[i] = i;
#if ( PRNTlevel>=1 )
	printf("Use natural column ordering.\n");
#endif
	return;
    case (MMD_ATA):  
	getata(m, n, Astore->nnz, Astore->colptr, Astore->rowind,
		     &bnz, &b_colptr, &b_rowind);
#if ( PRNTlevel>=1 )
	printf("Use minimum degree ordering on A'*A.\n");
#endif
	t = SuperLU_timer_() - t;
	break;
    case (MMD_AT_PLUS_A):  
	if ( m != n ) ABORT("Matrix is not square");
	at_plus_a(n, Astore->nnz, Astore->colptr, Astore->rowind,
		  &bnz, &b_colptr, &b_rowind);
#if ( PRNTlevel>=1 )
	printf("Use minimum degree ordering on A'+A.\n");
#endif
	t = SuperLU_timer_() - t;
	break;
    case (COLAMD):  
	get_colamd(m, n, Astore->nnz, Astore->colptr, Astore->rowind, perm_c);
#if ( PRNTlevel>=1 )
	printf(".. Use approximate minimum degree column ordering.\n");
#endif
	return; 
    default:
	ABORT("Invalid ISPEC");
    }
    if ( bnz != 0 ) {
	t = SuperLU_timer_();
	delta = 0;  
	maxint = 2147483647;  
	invp = (int *) SUPERLU_MALLOC((n+delta)*sizeof(int));
	if ( !invp ) ABORT("SUPERLU_MALLOC fails for invp.");
	dhead = (int *) SUPERLU_MALLOC((n+delta)*sizeof(int));
	if ( !dhead ) ABORT("SUPERLU_MALLOC fails for dhead.");
	qsize = (int *) SUPERLU_MALLOC((n+delta)*sizeof(int));
	if ( !qsize ) ABORT("SUPERLU_MALLOC fails for qsize.");
	llist = (int *) SUPERLU_MALLOC(n*sizeof(int));
	if ( !llist ) ABORT("SUPERLU_MALLOC fails for llist.");
	marker = (int *) SUPERLU_MALLOC(n*sizeof(int));
	if ( !marker ) ABORT("SUPERLU_MALLOC fails for marker.");
	for (i = 0; i <= n; ++i) ++b_colptr[i];
	for (i = 0; i < bnz; ++i) ++b_rowind[i];
	genmmd_(&n, b_colptr, b_rowind, perm_c, invp, &delta, dhead, 
		qsize, llist, marker, &maxint, &nofsub);
	for (i = 0; i < n; ++i) --perm_c[i];
	SUPERLU_FREE(invp);
	SUPERLU_FREE(dhead);
	SUPERLU_FREE(qsize);
	SUPERLU_FREE(llist);
	SUPERLU_FREE(marker);
	SUPERLU_FREE(b_rowind);
	t = SuperLU_timer_() - t;
    } else {  
	for (i = 0; i < n; ++i) perm_c[i] = i;
    }
    SUPERLU_FREE(b_colptr);
}