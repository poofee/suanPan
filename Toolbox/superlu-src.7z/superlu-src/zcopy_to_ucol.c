#include "slu_zdefs.h"
int
zcopy_to_ucol(
	      int        jcol,	   
	      int        nseg,	   
	      int        *segrep,   
	      int        *repfnz,   
	      int        *perm_r,   
	      doublecomplex     *dense,    
	      GlobalLU_t *Glu       
	      )
{
    int ksub, krep, ksupno;
    int i, k, kfnz, segsze;
    int fsupc, isub, irow;
    int jsupno, nextu;
    int new_next, mem_error;
    int       *xsup, *supno;
    int       *lsub, *xlsub;
    doublecomplex    *ucol;
    int       *usub, *xusub;
    int       nzumax;
    doublecomplex zero = {0.0, 0.0};
    xsup    = Glu->xsup;
    supno   = Glu->supno;
    lsub    = Glu->lsub;
    xlsub   = Glu->xlsub;
    ucol    = (doublecomplex *) Glu->ucol;
    usub    = Glu->usub;
    xusub   = Glu->xusub;
    nzumax  = Glu->nzumax;
    jsupno = supno[jcol];
    nextu  = xusub[jcol];
    k = nseg - 1;
    for (ksub = 0; ksub < nseg; ksub++) {
	krep = segrep[k--];
	ksupno = supno[krep];
	if ( ksupno != jsupno ) {  
	    kfnz = repfnz[krep];
	    if ( kfnz != EMPTY ) {	 
	    	fsupc = xsup[ksupno];
	        isub = xlsub[fsupc] + kfnz - fsupc;
	        segsze = krep - kfnz + 1;
		new_next = nextu + segsze;
		while ( new_next > nzumax ) {
		    if (mem_error = zLUMemXpand(jcol, nextu, UCOL, &nzumax, Glu))
			return (mem_error);
		    ucol = (doublecomplex *) Glu->ucol;
		    if (mem_error = zLUMemXpand(jcol, nextu, USUB, &nzumax, Glu))
			return (mem_error);
		    usub = Glu->usub;
		    lsub = Glu->lsub;
		}
		for (i = 0; i < segsze; i++) {
		    irow = lsub[isub];
		    usub[nextu] = perm_r[irow];
		    ucol[nextu] = dense[irow];
		    dense[irow] = zero;
		    nextu++;
		    isub++;
		} 
	    }
	}
    }  
    xusub[jcol + 1] = nextu;       
    return 0;
}