#include "slu_cdefs.h"
void
creadtriple(int *m, int *n, int *nonz,
	    complex **nzval, int **rowind, int **colptr)
{
    int    j, k, jsize, nnz, nz;
    complex *a, *val;
    int    *asub, *xa, *row, *col;
    int    zero_base = 0;
    scanf("%d%d", n, nonz);
    *m = *n;
    printf("m %d, n %d, nonz %d\n", *m, *n, *nonz);
    callocateA(*n, *nonz, nzval, rowind, colptr);  
    a    = *nzval;
    asub = *rowind;
    xa   = *colptr;
    val = (complex *) SUPERLU_MALLOC(*nonz * sizeof(complex));
    row = (int *) SUPERLU_MALLOC(*nonz * sizeof(int));
    col = (int *) SUPERLU_MALLOC(*nonz * sizeof(int));
    for (j = 0; j < *n; ++j) xa[j] = 0;
    for (nnz = 0, nz = 0; nnz < *nonz; ++nnz) {
	scanf("%d%d%f%f\n", &row[nz], &col[nz], &val[nz].r, &val[nz].i);
        if ( nnz == 0 ) {  
	    if ( row[0] == 0 || col[0] == 0 ) {
		zero_base = 1;
		printf("triplet file: row/col indices are zero-based.\n");
	    } else
		printf("triplet file: row/col indices are one-based.\n");
        }
        if ( !zero_base ) { 
	  --row[nz];
	  --col[nz];
        }
	if (row[nz] < 0 || row[nz] >= *m || col[nz] < 0 || col[nz] >= *n
	     ) {
	    fprintf(stderr, "nz %d, (%d, %d) = (%e,%e) out of bound, removed\n",
		    nz, row[nz], col[nz], val[nz].r, val[nz].i);
	    exit(-1);
	} else {
	    ++xa[col[nz]];
	    ++nz;
	}
    }
    *nonz = nz;
    k = 0;
    jsize = xa[0];
    xa[0] = 0;
    for (j = 1; j < *n; ++j) {
	k += jsize;
	jsize = xa[j];
	xa[j] = k;
    }
    for (nz = 0; nz < *nonz; ++nz) {
	j = col[nz];
	k = xa[j];
	asub[k] = row[nz];
	a[k] = val[nz];
	++xa[j];
    }
    for (j = *n; j > 0; --j)
	xa[j] = xa[j-1];
    xa[0] = 0;
    SUPERLU_FREE(val);
    SUPERLU_FREE(row);
    SUPERLU_FREE(col);
#ifdef CHK_INPUT
    {
	int i;
	for (i = 0; i < *n; i++) {
	    printf("Col %d, xa %d\n", i, xa[i]);
	    for (k = xa[i]; k < xa[i+1]; k++)
		printf("%d\t%16.10f\n", asub[k], a[k]);
	}
    }
#endif
}
void creadrhs(int m, complex *b)
{
    FILE *fp, *fopen();
    int i;
    if ( !(fp = fopen("b.dat", "r")) ) {
        fprintf(stderr, "dreadrhs: file does not exist\n");
	exit(-1);
    }
    for (i = 0; i < m; ++i)
      fscanf(fp, "%f%f\n", &b[i].r, &b[i].i);
    fclose(fp);
}