#include "slu_zdefs.h"
void
zpruneL(
       const int  jcol,	      
       const int  *perm_r,    
       const int  pivrow,     
       const int  nseg,	      
       const int  *segrep,    
       const int  *repfnz,    
       int        *xprune,    
       GlobalLU_t *Glu        
       )
{
    doublecomplex     utemp;
    int        jsupno, irep, irep1, kmin, kmax, krow, movnum;
    int        i, ktemp, minloc, maxloc;
    int        do_prune;  
    int        *xsup, *supno;
    int        *lsub, *xlsub;
    doublecomplex     *lusup;
    int        *xlusup;
    xsup       = Glu->xsup;
    supno      = Glu->supno;
    lsub       = Glu->lsub;
    xlsub      = Glu->xlsub;
    lusup      = (doublecomplex *) Glu->lusup;
    xlusup     = Glu->xlusup;
    jsupno = supno[jcol];
    for (i = 0; i < nseg; i++) {
	irep = segrep[i];
	irep1 = irep + 1;
	do_prune = FALSE;
 	if ( repfnz[irep] == EMPTY )
		continue;
	if ( supno[irep] == supno[irep1] ) 	 
		continue;
	if ( supno[irep] != jsupno ) {
	    if ( xprune[irep] >= xlsub[irep1] ) {
		kmin = xlsub[irep];
		kmax = xlsub[irep1] - 1;
		for (krow = kmin; krow <= kmax; krow++) 
		    if ( lsub[krow] == pivrow ) {
			do_prune = TRUE;
			break;
		    }
	    }
    	    if ( do_prune ) {
	        movnum = FALSE;
	        if ( irep == xsup[supno[irep]] )  
			movnum = TRUE;
	        while ( kmin <= kmax ) {
	    	    if ( perm_r[lsub[kmax]] == EMPTY ) 
			kmax--;
		    else if ( perm_r[lsub[kmin]] != EMPTY )
			kmin++;
		    else {  
		        ktemp = lsub[kmin];
		        lsub[kmin] = lsub[kmax];
		        lsub[kmax] = ktemp;
		        if ( movnum ) {
		    	    minloc = xlusup[irep] + (kmin - xlsub[irep]);
		    	    maxloc = xlusup[irep] + (kmax - xlsub[irep]);
			    utemp = lusup[minloc];
		  	    lusup[minloc] = lusup[maxloc];
			    lusup[maxloc] = utemp;
		        }
		        kmin++;
		        kmax--;
		    }
	        }  
	        xprune[irep] = kmin;	 
#ifdef CHK_PRUNE
	printf("    After zpruneL(),using col %d:  xprune[%d] = %d\n", 
			jcol, irep, kmin);
#endif
	    }  
	}  
    }  
}