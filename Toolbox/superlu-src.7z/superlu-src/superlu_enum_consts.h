#ifndef __SUPERLU_ENUM_CONSTS  
#define __SUPERLU_ENUM_CONSTS
typedef enum {NO, YES}                                          yes_no_t;
typedef enum {DOFACT, SamePattern, SamePattern_SameRowPerm, FACTORED} fact_t;
typedef enum {NOROWPERM, LargeDiag, MY_PERMR}                   rowperm_t;
typedef enum {NATURAL, MMD_ATA, MMD_AT_PLUS_A, COLAMD,
	      METIS_AT_PLUS_A, PARMETIS, ZOLTAN, MY_PERMC}      colperm_t;
typedef enum {NOTRANS, TRANS, CONJ}                             trans_t;
typedef enum {NOEQUIL, ROW, COL, BOTH}                          DiagScale_t;
typedef enum {NOREFINE, SLU_SINGLE=1, SLU_DOUBLE, SLU_EXTRA}    IterRefine_t;
typedef enum {LUSUP, UCOL, LSUB, USUB, LLVL, ULVL}              MemType;
typedef enum {HEAD, TAIL}                                       stack_end_t;
typedef enum {SYSTEM, USER}                                     LU_space_t;
typedef enum {ONE_NORM, TWO_NORM, INF_NORM}			norm_t;
typedef enum {SILU, SMILU_1, SMILU_2, SMILU_3}			milu_t;
#if 0
typedef enum {NODROP		= 0x0000,
	      DROP_BASIC	= 0x0001,  
	      DROP_PROWS	= 0x0002,  
	      DROP_COLUMN	= 0x0004,  
	      DROP_AREA 	= 0x0008,  
	      DROP_SECONDARY	= 0x000E,  
	      DROP_DYNAMIC	= 0x0010,
	      DROP_INTERP	= 0x0100}			rule_t;
#endif
typedef enum {
    COLPERM,  
    ROWPERM,  
    RELAX,    
    ETREE,    
    EQUIL,    
    SYMBFAC,  
    DIST,     
    FACT,     
    COMM,     
    SOL_COMM, 
    RCOND,    
    SOLVE,    
    REFINE,   
    TRSV,     
    GEMV,     
    FERR,     
    NPHASES   
} PhaseType;
#endif  