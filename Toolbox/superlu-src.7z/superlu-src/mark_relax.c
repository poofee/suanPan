#include "slu_ddefs.h"
int mark_relax(
	int n,		     
	int *relax_end,      
	int *relax_fsupc,    
	int *xa_begin,	     
	int *xa_end,	     
	int *asub,	     
	int *marker	      )
{
    register int jcol, kcol;
    register int i, j, k;
    for (i = 0; i < n && relax_fsupc[i] != EMPTY; i++)
    {
	jcol = relax_fsupc[i];	 
	kcol = relax_end[jcol];  
	for (j = jcol; j <= kcol; j++)
	    for (k = xa_begin[j]; k < xa_end[j]; k++)
		marker[asub[k]] = jcol;
    }
    return i;
}