#include <float.h>
#include <math.h>
#include <stdio.h>
double dmach(char *cmach)
{
    double sfmin, small, rmach;
    if (strncmp(cmach, "E", 1)==0) {
	rmach = DBL_EPSILON * 0.5;
    } else if (strncmp(cmach, "S", 1)==0) {
	sfmin = DBL_MIN;
	small = 1. / DBL_MAX;
	if (small >= sfmin) {
	    sfmin = small * (DBL_EPSILON*0.5 + 1.);
	}
	rmach = sfmin;
    } else if (strncmp(cmach, "B", 1)==0) {
	rmach = FLT_RADIX;
    } else if (strncmp(cmach, "P", 1)==0) {
	rmach = DBL_EPSILON * 0.5 * FLT_RADIX;
    } else if (strncmp(cmach, "N", 1)==0) {
	rmach = DBL_MANT_DIG;
    } else if (strncmp(cmach, "R", 1)==0) {
	rmach = FLT_ROUNDS;
    } else if (strncmp(cmach, "M", 1)==0) {
	rmach = DBL_MIN_EXP;
    } else if (strncmp(cmach, "U", 1)==0) {
	rmach = DBL_MIN;
    } else if (strncmp(cmach, "L", 1)==0) {
	rmach = DBL_MAX_EXP;
    } else if (strncmp(cmach, "O", 1)==0) {
	rmach = DBL_MAX;
    }
    return rmach;
}  