#include "slu_ddefs.h"
void
ilu_relax_snode (
	      const	int n,
	      int	*et,	        
	      const int relax_columns,  
	      int	*descendants,   
	      int	*relax_end,     
	      int	*relax_fsupc    
	     )
{
    register int j, f, parent;
    register int snode_start;	 
    ifill (relax_end, n, EMPTY);
    ifill (relax_fsupc, n, EMPTY);
    for (j = 0; j < n; j++) descendants[j] = 0;
    for (j = 0; j < n; j++) {
	parent = et[j];
	if ( parent != n )   
	    descendants[parent] += descendants[j] + 1;
    }
    for (j = f = 0; j < n; ) {
	parent = et[j];
	snode_start = j;
	while ( parent != n && descendants[parent] < relax_columns ) {
	    j = parent;
	    parent = et[j];
	}
	relax_end[snode_start] = j;		 
	j++;
	relax_fsupc[f++] = snode_start;
	while ( descendants[j] != 0 && j < n ) j++;
    }
}