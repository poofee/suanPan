#include <math.h>
#include <stdlib.h>
#include "slu_zdefs.h"
#undef DEBUG
int
zpivotL(
        const int  jcol,      
        const double u,       
        int        *usepr,    
        int        *perm_r,   
        int        *iperm_r,  
        int        *iperm_c,  
        int        *pivrow,   
        GlobalLU_t *Glu,      
	SuperLUStat_t *stat   
       )
{
    doublecomplex one = {1.0, 0.0};
    int          fsupc;	     
    int          nsupc;	     
    int          nsupr;      
    int          lptr;	     
    int          pivptr, old_pivptr, diag, diagind;
    double       pivmax, rtemp, thresh;
    doublecomplex       temp;
    doublecomplex       *lu_sup_ptr; 
    doublecomplex       *lu_col_ptr;
    int          *lsub_ptr;
    int          isub, icol, k, itemp;
    int          *lsub, *xlsub;
    doublecomplex       *lusup;
    int          *xlusup;
    flops_t      *ops = stat->ops;
    lsub       = Glu->lsub;
    xlsub      = Glu->xlsub;
    lusup      = (doublecomplex *) Glu->lusup;
    xlusup     = Glu->xlusup;
    fsupc      = (Glu->xsup)[(Glu->supno)[jcol]];
    nsupc      = jcol - fsupc;	         
    lptr       = xlsub[fsupc];
    nsupr      = xlsub[fsupc+1] - lptr;
    lu_sup_ptr = &lusup[xlusup[fsupc]];	 
    lu_col_ptr = &lusup[xlusup[jcol]];	 
    lsub_ptr   = &lsub[lptr];	 
#ifdef DEBUG
if ( jcol == MIN_COL ) {
    printf("Before cdiv: col %d\n", jcol);
    for (k = nsupc; k < nsupr; k++) 
	printf("  lu[%d] %f\n", lsub_ptr[k], lu_col_ptr[k]);
}
#endif
    if ( *usepr ) *pivrow = iperm_r[jcol];
    diagind = iperm_c[jcol];
    pivmax = 0.0;
    pivptr = nsupc;
    diag = EMPTY;
    old_pivptr = nsupc;
    for (isub = nsupc; isub < nsupr; ++isub) {
        rtemp = z_abs1 (&lu_col_ptr[isub]);
	if ( rtemp > pivmax ) {
	    pivmax = rtemp;
	    pivptr = isub;
	}
	if ( *usepr && lsub_ptr[isub] == *pivrow ) old_pivptr = isub;
	if ( lsub_ptr[isub] == diagind ) diag = isub;
    }
    if ( pivmax == 0.0 ) {
#if 1
	*pivrow = lsub_ptr[pivptr];
	perm_r[*pivrow] = jcol;
#else
	perm_r[diagind] = jcol;
#endif
	*usepr = 0;
	return (jcol+1);
    }
    thresh = u * pivmax;
    if ( *usepr ) {
        rtemp = z_abs1 (&lu_col_ptr[old_pivptr]);
	if ( rtemp != 0.0 && rtemp >= thresh )
	    pivptr = old_pivptr;
	else
	    *usepr = 0;
    }
    if ( *usepr == 0 ) {
	if ( diag >= 0 ) {  
            rtemp = z_abs1 (&lu_col_ptr[diag]);
	    if ( rtemp != 0.0 && rtemp >= thresh ) pivptr = diag;
        }
	*pivrow = lsub_ptr[pivptr];
    }
    perm_r[*pivrow] = jcol;
    if ( pivptr != nsupc ) {
	itemp = lsub_ptr[pivptr];
	lsub_ptr[pivptr] = lsub_ptr[nsupc];
	lsub_ptr[nsupc] = itemp;
	for (icol = 0; icol <= nsupc; icol++) {
	    itemp = pivptr + icol * nsupr;
	    temp = lu_sup_ptr[itemp];
	    lu_sup_ptr[itemp] = lu_sup_ptr[nsupc + icol*nsupr];
	    lu_sup_ptr[nsupc + icol*nsupr] = temp;
	}
    }  
    ops[FACT] += 10 * (nsupr - nsupc);
    z_div(&temp, &one, &lu_col_ptr[nsupc]);
    for (k = nsupc+1; k < nsupr; k++) 
	zz_mult(&lu_col_ptr[k], &lu_col_ptr[k], &temp);
    return 0;
}