#include "slu_ddefs.h"
void
ilu_dpanel_dfs(
   const int  m,	    
   const int  w,	    
   const int  jcol,	    
   SuperMatrix *A,	    
   int	      *perm_r,	    
   int	      *nseg,	    
   double     *dense,	    
   double     *amax,	    
   int	      *panel_lsub,  
   int	      *segrep,	    
   int	      *repfnz,	    
   int	      *marker,	    
   int	      *parent,	    
   int	      *xplore,	    
   GlobalLU_t *Glu	    
)
{
    NCPformat *Astore;
    double    *a;
    int       *asub;
    int       *xa_begin, *xa_end;
    int       krep, chperm, chmark, chrep, oldrep, kchild, myfnz;
    int       k, krow, kmark, kperm;
    int       xdfs, maxdfs, kpar;
    int       jj;	    
    int       *marker1;     
    int       *repfnz_col;  
    double    *dense_col;   
    int       nextl_col;    
    int       *xsup, *supno;
    int       *lsub, *xlsub;
    double    *amax_col;
    register double tmp;
    Astore     = A->Store;
    a	       = Astore->nzval;
    asub       = Astore->rowind;
    xa_begin   = Astore->colbeg;
    xa_end     = Astore->colend;
    marker1    = marker + m;
    repfnz_col = repfnz;
    dense_col  = dense;
    amax_col   = amax;
    *nseg      = 0;
    xsup       = Glu->xsup;
    supno      = Glu->supno;
    lsub       = Glu->lsub;
    xlsub      = Glu->xlsub;
    for (jj = jcol; jj < jcol + w; jj++) {
	nextl_col = (jj - jcol) * m;
#ifdef CHK_DFS
	printf("\npanel col %d: ", jj);
#endif
	*amax_col = 0.0;
	for (k = xa_begin[jj]; k < xa_end[jj]; k++) {
	    krow = asub[k];
	    tmp = fabs(a[k]);
	    if (tmp > *amax_col) *amax_col = tmp;
	    dense_col[krow] = a[k];
	    kmark = marker[krow];
	    if ( kmark == jj )
		continue;      
	    marker[krow] = jj;
	    kperm = perm_r[krow];
	    if ( kperm == EMPTY ) {
		panel_lsub[nextl_col++] = krow;  
	    }
	    else {
		krep = xsup[supno[kperm]+1] - 1;
		myfnz = repfnz_col[krep];
#ifdef CHK_DFS
		printf("krep %d, myfnz %d, perm_r[%d] %d\n", krep, myfnz, krow, kperm);
#endif
		if ( myfnz != EMPTY ) {  
		    if ( myfnz > kperm ) repfnz_col[krep] = kperm;
		}
		else {
		    oldrep = EMPTY;
		    parent[krep] = oldrep;
		    repfnz_col[krep] = kperm;
		    xdfs = xlsub[xsup[supno[krep]]];
		    maxdfs = xlsub[krep + 1];
#ifdef CHK_DFS
		    printf("  xdfs %d, maxdfs %d: ", xdfs, maxdfs);
		    for (i = xdfs; i < maxdfs; i++) printf(" %d", lsub[i]);
		    printf("\n");
#endif
		    do {
			while ( xdfs < maxdfs ) {
			    kchild = lsub[xdfs];
			    xdfs++;
			    chmark = marker[kchild];
			    if ( chmark != jj ) {  
				marker[kchild] = jj;
				chperm = perm_r[kchild];
				if ( chperm == EMPTY ) {
				    panel_lsub[nextl_col++] = kchild;
				}
				else {
				    chrep = xsup[supno[chperm]+1] - 1;
				    myfnz = repfnz_col[chrep];
#ifdef CHK_DFS
				    printf("chrep %d,myfnz %d,perm_r[%d] %d\n",chrep,myfnz,kchild,chperm);
#endif
				    if ( myfnz != EMPTY ) {  
					if ( myfnz > chperm )
					    repfnz_col[chrep] = chperm;
				    }
				    else {
					xplore[krep] = xdfs;
					oldrep = krep;
					krep = chrep;  
					parent[krep] = oldrep;
					repfnz_col[krep] = chperm;
					xdfs = xlsub[xsup[supno[krep]]];
					maxdfs = xlsub[krep + 1];
#ifdef CHK_DFS
					printf("  xdfs %d, maxdfs %d: ", xdfs, maxdfs);
					for (i = xdfs; i < maxdfs; i++) printf(" %d", lsub[i]);
					printf("\n");
#endif
				    }  
				}  
			    }  
			}  
			if ( marker1[krep] < jcol ) {
			    segrep[*nseg] = krep;
			    ++(*nseg);
			    marker1[krep] = jj;
			}
			kpar = parent[krep];  
			if ( kpar == EMPTY ) break;  
			krep = kpar;
			xdfs = xplore[krep];
			maxdfs = xlsub[krep + 1];
#ifdef CHK_DFS
			printf("  pop stack: krep %d,xdfs %d,maxdfs %d: ", krep,xdfs,maxdfs);
			for (i = xdfs; i < maxdfs; i++) printf(" %d", lsub[i]);
			printf("\n");
#endif
		    } while ( kpar != EMPTY );  
		}  
	    }  
	}  
	repfnz_col += m;     
	dense_col += m;
	amax_col++;
    }  
}