#include "slu_ddefs.h"
#define abs(a) ((a) >= 0) ? (a) : -(a)
#define min(a,b) ((a) < (b)) ? (a) : (b)
#if 0
static int_t c__1 = 1;
static int_t c__2 = 2;
#endif
  int_t mc64id_(int_t *icntl)
{
    int_t i__;
    --icntl;
    icntl[1] = 6;
    icntl[2] = 6;
    icntl[3] = -1;
    for (i__ = 4; i__ <= 10; ++i__) {
	icntl[i__] = 0;
    }
    return 0;
}  
  int_t mc64ad_(int_t *job, int_t *n, int_t *ne, int_t *
	ip, int_t *irn, double *a, int_t *num, int_t *cperm, 
	int_t *liw, int_t *iw, int_t *ldw, double *dw, int_t *
	icntl, int_t *info)
{
    int_t i__1, i__2;
    double d__1, d__2;
    double log(double);
    int_t i__, j, k;
    double fact, rinf;
    extern   int_t mc21ad_(int_t *, int_t *, int_t *, 
	    int_t *, int_t *, int_t *, int_t *, int_t *), mc64bd_(
	    int_t *, int_t *, int_t *, int_t *, double *, int_t 
	    *, int_t *, int_t *, int_t *, int_t *, int_t *, 
	    double *), mc64rd_(int_t *, int_t *, int_t *, int_t *,
	     double *), mc64sd_(int_t *, int_t *, int_t *, int_t *
	    , double *, int_t *, int_t *, int_t *, int_t *, 
	    int_t *, int_t *, int_t *, int_t *, int_t *), mc64wd_(
	    int_t *, int_t *, int_t *, int_t *, double *, int_t 
	    *, int_t *, int_t *, int_t *, int_t *, int_t *, int_t 
	    *, double *, double *);
    --cperm;
    --ip;
    --a;
    --irn;
    --iw;
    --dw;
    --icntl;
    --info;
    rinf = dmach("Overflow");
    if (*job < 1 || *job > 5) {
	info[1] = -1;
	info[2] = *job;
	if (icntl[1] >= 0) {
	    printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
		   " because JOB = %d\n", info[1], *job);
	}
	goto L99;
    }
    if (*n < 1) {
	info[1] = -2;
	info[2] = *n;
	if (icntl[1] >= 0) {
	    printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
		   " because N = %d\n", info[1], *job);
	}
	goto L99;
    }
    if (*ne < 1) {
	info[1] = -3;
	info[2] = *ne;
	if (icntl[1] >= 0) {
	    printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
		   " because NE = %d\n", info[1], *job);
	}
	goto L99;
    }
    if (*job == 1) {
	k = *n * 5;
    }
    if (*job == 2) {
	k = *n << 2;
    }
    if (*job == 3) {
	k = *n * 10 + *ne;
    }
    if (*job == 4) {
	k = *n * 5;
    }
    if (*job == 5) {
	k = *n * 5;
    }
    if (*liw < k) {
	info[1] = -4;
	info[2] = k;
	if (icntl[1] >= 0) {
	    printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
		   " LIW too small, must be at least %8d\n", info[1], k);
	}
	goto L99;
    }
    if (*job > 1) {
	if (*job == 2) {
	    k = *n;
	}
	if (*job == 3) {
	    k = *ne;
	}
	if (*job == 4) {
	    k = (*n << 1) + *ne;
	}
	if (*job == 5) {
	    k = *n * 3 + *ne;
	}
	if (*ldw < k) {
	    info[1] = -5;
	    info[2] = k;
	    if (icntl[1] >= 0) {
		printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
		       " LDW too small, must be at least %8d\n", info[1], k);
	    }
	    goto L99;
	}
    }
    if (icntl[4] == 0) {
	i__1 = *n;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    iw[i__] = 0;
	}
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		i__ = irn[k];
		if (i__ < 1 || i__ > *n) {
		    info[1] = -6;
		    info[2] = j;
		    if (icntl[1] >= 0) {
			printf(" ****** Error in MC64A/AD. INFO(1) = %2d Column %8d"
			       " contains an entry with invalid row index %8d\n",
			       info[1], j, i__);
		    }
		    goto L99;
		}
		if (iw[i__] == j) {
		    info[1] = -7;
		    info[2] = j;
		    if (icntl[1] >= 0) {
			printf(" ****** Error in MC64A/AD. INFO(1) = %2d"
			       "        Column %8d"
			       " contains two or more entries with row index %8d\n",
			       info[1], j, i__);
		    }
		    goto L99;
		} else {
		    iw[i__] = j;
		}
	    }
	    }
    }
    if (icntl[3] >= 0) {
	printf("  ****** Input parameters for MC64A/AD: JOB = %8d,"
	       " N = %d, NE = %8d\n", *job, *n, *ne);
	printf(" IP(1:N+1)   = ");
	for (j=1; j<=(*n+1); ++j) {
	    printf("%8d", ip[j]);
	    if (j%8 == 0) printf("\n");
	}
	printf("\n IRN(1:NE) = ");
	for (j=1; j<=(*ne); ++j) {
	    printf("%8d", irn[j]);
	    if (j%8 == 0) printf("\n");
	}
	printf("\n");
	if (*job > 1) {
	    printf(" A(1:NE)     = ");
	    for (j=1; j<=(*ne); ++j) {
		printf("%f14.4", a[j]);
		if (j%4 == 0) printf("\n");
	    }
	    printf("\n");
	}
    }
    for (i__ = 1; i__ <= 10; ++i__) {
	info[i__] = 0;
    }
    if (*job == 1) {
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    iw[j] = ip[j + 1] - ip[j];
	}
#if 0
	mc21ad_(n, &irn[1], ne, &ip[1], &iw[1], &cperm[1], num, &iw[*n+1]);
#else
	printf(" ****** Warning from MC64A/AD. Need to link mc21ad.\n");
#endif
	goto L90;
    }
    if (*job == 2) {
	mc64bd_(n, ne, &ip[1], &irn[1], &a[1], &cperm[1], num, &iw[1], &iw[*n 
		+ 1], &iw[(*n << 1) + 1], &iw[*n * 3 + 1], &dw[1]);
	goto L90;
    }
    if (*job == 3) {
	i__1 = *ne;
	for (k = 1; k <= i__1; ++k) {
	    iw[k] = irn[k];
	    dw[k] = (d__1 = a[k], abs(d__1));
	}
	mc64rd_(n, ne, &ip[1], &iw[1], &dw[1]);
	mc64sd_(n, ne, &ip[1], &iw[1], &dw[1], &cperm[1], num, &iw[*ne + 1], &
		iw[*ne + *n + 1], &iw[*ne + (*n << 1) + 1], &iw[*ne + *n * 3 
		+ 1], &iw[*ne + (*n << 2) + 1], &iw[*ne + *n * 5 + 1], &iw[*
		ne + *n * 6 + 1]);
	goto L90;
    }
    if (*job == 4) {
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    fact = 0.;
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		if ((d__1 = a[k], abs(d__1)) > fact) {
		    fact = (d__2 = a[k], abs(d__2));
		}
	    }
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		dw[(*n << 1) + k] = fact - (d__1 = a[k], abs(d__1));
	    }
	}
	mc64wd_(n, ne, &ip[1], &irn[1], &dw[(*n << 1) + 1], &cperm[1], num, &
		iw[1], &iw[*n + 1], &iw[(*n << 1) + 1], &iw[*n * 3 + 1], &iw[(
		*n << 2) + 1], &dw[1], &dw[*n + 1]);
	goto L90;
    }
    if (*job == 5) {
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    fact = 0.;
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		dw[*n * 3 + k] = (d__1 = a[k], abs(d__1));
		if (dw[*n * 3 + k] > fact) {
		    fact = dw[*n * 3 + k];
		}
	    }
	    dw[(*n << 1) + j] = fact;
	    if (fact != 0.) {
		fact = log(fact);
	    } else {
		fact = rinf / *n;
	    }
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		if (dw[*n * 3 + k] != 0.) {
		    dw[*n * 3 + k] = fact - log(dw[*n * 3 + k]);
		} else {
		    dw[*n * 3 + k] = rinf / *n;
		}
	    }
	}
	mc64wd_(n, ne, &ip[1], &irn[1], &dw[*n * 3 + 1], &cperm[1], num, &iw[
		1], &iw[*n + 1], &iw[(*n << 1) + 1], &iw[*n * 3 + 1], &iw[(*n 
		<< 2) + 1], &dw[1], &dw[*n + 1]);
	if (*num == *n) {
	    i__1 = *n;
	    for (j = 1; j <= i__1; ++j) {
		if (dw[(*n << 1) + j] != 0.) {
		    dw[*n + j] -= log(dw[(*n << 1) + j]);
		} else {
		    dw[*n + j] = 0.;
		}
	    }
	}
	fact = log(rinf) * .5f;
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    if (dw[j] < fact && dw[*n + j] < fact) {
		goto L86;
	    }
	    info[1] = 2;
	    goto L90;
L86:
	    ;
	}
    }
L90:
    if (info[1] == 0 && *num < *n) {
	info[1] = 1;
	if (icntl[2] >= 0) {
	    printf(" ****** Warning from MC64A/AD. INFO(1) = %2d"
		   " The matrix is structurally singular.\n", info[1]);
	}
    }
    if (info[1] == 2) {
	if (icntl[2] >= 0) {
	    printf(" ****** Warning from MC64A/AD. INFO(1) = %2d\n"
		   "        Some scaling factors may be too large.\n", info[1]);
	}
    }
    if (icntl[3] >= 0) {
	printf(" ****** Output parameters for MC64A/AD: INFO(1:2)  = %8d%8d\n",
	       info[1], info[2]);
	printf(" NUM        = %8d", *num);
	printf(" CPERM(1:N) = ");
	for (j=1; j<=*n; ++j) {
	    printf("%8d", cperm[j]);
	    if (j%8 == 0) printf("\n");
	}
	if (*job == 5) {
	    printf("\n DW(1:N)    = ");
	    for (j=1; j<=*n; ++j) {
		printf("%11.3f", dw[j]);
		if (j%5 == 0) printf("\n");
	    }
	    printf("\n DW(N+1:2N) = ");
	    for (j=1; j<=*n; ++j) {
		printf("%11.3f", dw[*n+j]);
		if (j%5 == 0) printf("\n");
	    }
	    printf("\n");
	}
    }
L99:
    return 0;
}  
  int_t mc64bd_(int_t *n, int_t *ne, int_t *ip, int_t *
	irn, double *a, int_t *iperm, int_t *num, int_t *jperm, 
	int_t *pr, int_t *q, int_t *l, double *d__)
{
    int_t i__1, i__2, i__3;
    double d__1, d__2, d__3;
    int_t c__1 = 1;
    int_t i__, j, k;
    double a0;
    int_t i0, q0;
    double ai, di;
    int_t ii, jj, kk;
    double bv;
    int_t up;
    double dq0;
    int_t kk1, kk2;
    double csp;
    int_t isp, jsp, low;
    double dnew;
    int_t jord, qlen, idum, jdum;
    double rinf;
    extern   int_t mc64dd_(int_t *, int_t *, int_t *, 
	    double *, int_t *, int_t *), mc64ed_(int_t *, int_t *,
	     int_t *, double *, int_t *, int_t *), mc64fd_(int_t *
	    , int_t *, int_t *, int_t *, double *, int_t *, int_t *);
    --d__;
    --l;
    --q;
    --pr;
    --jperm;
    --iperm;
    --ip;
    --a;
    --irn;
    rinf = dmach("Overflow");
    *num = 0;
    bv = rinf;
    i__1 = *n;
    for (k = 1; k <= i__1; ++k) {
	iperm[k] = 0;
	jperm[k] = 0;
	pr[k] = ip[k];
	d__[k] = 0.;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	a0 = -1.;
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    i__ = irn[k];
	    ai = (d__1 = a[k], abs(d__1));
	    if (ai > d__[i__]) {
		d__[i__] = ai;
	    }
	    if (jperm[j] != 0) {
		goto L30;
	    }
	    if (ai >= bv) {
		a0 = bv;
		if (iperm[i__] != 0) {
		    goto L30;
		}
		jperm[j] = i__;
		iperm[i__] = j;
		++(*num);
	    } else {
		if (ai <= a0) {
		    goto L30;
		}
		a0 = ai;
		i0 = i__;
	    }
L30:
	    ;
	}
	if (a0 != -1. && a0 < bv) {
	    bv = a0;
	    if (iperm[i0] != 0) {
		goto L20;
	    }
	    iperm[i0] = j;
	    jperm[j] = i0;
	    ++(*num);
	}
L20:
	;
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	d__1 = bv, d__2 = d__[i__];
	bv = min(d__1,d__2);
    }
    if (*num == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	if (jperm[j] != 0) {
	    goto L95;
	}
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    i__ = irn[k];
	    ai = (d__1 = a[k], abs(d__1));
	    if (ai < bv) {
		goto L50;
	    }
	    if (iperm[i__] == 0) {
		goto L90;
	    }
	    jj = iperm[i__];
	    kk1 = pr[jj];
	    kk2 = ip[jj + 1] - 1;
	    if (kk1 > kk2) {
		goto L50;
	    }
	    i__3 = kk2;
	    for (kk = kk1; kk <= i__3; ++kk) {
		ii = irn[kk];
		if (iperm[ii] != 0) {
		    goto L70;
		}
		if ((d__1 = a[kk], abs(d__1)) >= bv) {
		    goto L80;
		}
L70:
		;
	    }
	    pr[jj] = kk2 + 1;
L50:
	    ;
	}
	goto L95;
L80:
	jperm[jj] = ii;
	iperm[ii] = jj;
	pr[jj] = kk + 1;
L90:
	++(*num);
	jperm[j] = i__;
	iperm[i__] = j;
	pr[j] = k + 1;
L95:
	;
    }
    if (*num == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	d__[i__] = -1.;
	l[i__] = 0;
    }
    i__1 = *n;
    for (jord = 1; jord <= i__1; ++jord) {
	if (jperm[jord] != 0) {
	    goto L100;
	}
	qlen = 0;
	low = *n + 1;
	up = *n + 1;
	csp = -1.;
	j = jord;
	pr[j] = -1;
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    i__ = irn[k];
	    dnew = (d__1 = a[k], abs(d__1));
	    if (csp >= dnew) {
		goto L115;
	    }
	    if (iperm[i__] == 0) {
		csp = dnew;
		isp = i__;
		jsp = j;
		if (csp >= bv) {
		    goto L160;
		}
	    } else {
		d__[i__] = dnew;
		if (dnew >= bv) {
		    --low;
		    q[low] = i__;
		} else {
		    ++qlen;
		    l[i__] = qlen;
		    mc64dd_(&i__, n, &q[1], &d__[1], &l[1], &c__1);
		}
		jj = iperm[i__];
		pr[jj] = j;
	    }
L115:
	    ;
	}
	i__2 = *num;
	for (jdum = 1; jdum <= i__2; ++jdum) {
	    if (low == up) {
		if (qlen == 0) {
		    goto L160;
		}
		i__ = q[1];
		if (csp >= d__[i__]) {
		    goto L160;
		}
		bv = d__[i__];
		i__3 = *n;
		for (idum = 1; idum <= i__3; ++idum) {
		    mc64ed_(&qlen, n, &q[1], &d__[1], &l[1], &c__1);
		    l[i__] = 0;
		    --low;
		    q[low] = i__;
		    if (qlen == 0) {
			goto L153;
		    }
		    i__ = q[1];
		    if (d__[i__] != bv) {
			goto L153;
		    }
		}
	    }
L153:
	    --up;
	    q0 = q[up];
	    dq0 = d__[q0];
	    l[q0] = up;
	    j = iperm[q0];
	    i__3 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__3; ++k) {
		i__ = irn[k];
		if (l[i__] >= up) {
		    goto L155;
		}
		d__2 = dq0, d__3 = (d__1 = a[k], abs(d__1));
		dnew = min(d__2,d__3);
		if (csp >= dnew) {
		    goto L155;
		}
		if (iperm[i__] == 0) {
		    csp = dnew;
		    isp = i__;
		    jsp = j;
		    if (csp >= bv) {
			goto L160;
		    }
		} else {
		    di = d__[i__];
		    if (di >= bv || di >= dnew) {
			goto L155;
		    }
		    d__[i__] = dnew;
		    if (dnew >= bv) {
			if (di != -1.) {
			    mc64fd_(&l[i__], &qlen, n, &q[1], &d__[1], &l[1], 
				    &c__1);
			}
			l[i__] = 0;
			--low;
			q[low] = i__;
		    } else {
			if (di == -1.) {
			    ++qlen;
			    l[i__] = qlen;
			}
			mc64dd_(&i__, n, &q[1], &d__[1], &l[1], &c__1);
		    }
		    jj = iperm[i__];
		    pr[jj] = j;
		}
L155:
		;
	    }
	}
L160:
	if (csp == -1.) {
	    goto L190;
	}
	bv = min(bv,csp);
	++(*num);
	i__ = isp;
	j = jsp;
	i__2 = *num + 1;
	for (jdum = 1; jdum <= i__2; ++jdum) {
	    i0 = jperm[j];
	    jperm[j] = i__;
	    iperm[i__] = j;
	    j = pr[j];
	    if (j == -1) {
		goto L190;
	    }
	    i__ = i0;
	}
L190:
	i__2 = *n;
	for (kk = up; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    d__[i__] = -1.;
	    l[i__] = 0;
	}
	i__2 = up - 1;
	for (kk = low; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    d__[i__] = -1.;
	}
	i__2 = qlen;
	for (kk = 1; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    d__[i__] = -1.;
	    l[i__] = 0;
	}
L100:
	;
    }
    if (*num == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	jperm[j] = 0;
    }
    k = 0;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (iperm[i__] == 0) {
	    ++k;
	    pr[k] = i__;
	} else {
	    j = iperm[i__];
	    jperm[j] = i__;
	}
    }
    k = 0;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (jperm[i__] != 0) {
	    goto L320;
	}
	++k;
	jdum = pr[k];
	iperm[jdum] = i__;
L320:
	;
    }
L1000:
    return 0;
}  
  int_t mc64dd_(int_t *i__, int_t *n, int_t *q, double 
	*d__, int_t *l, int_t *iway)
{
    int_t i__1;
    int_t c__1 = 1;
    double di;
    int_t qk, pos, idum, posk;
    --l;
    --d__;
    --q;
    di = d__[*i__];
    pos = l[*i__];
    if (*iway == 1) {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    if (pos <= 1) {
		goto L20;
	    }
	    posk = pos / 2;
	    qk = q[posk];
	    if (di <= d__[qk]) {
		goto L20;
	    }
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
    } else {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    if (pos <= 1) {
		goto L20;
	    }
	    posk = pos / 2;
	    qk = q[posk];
	    if (di >= d__[qk]) {
		goto L20;
	    }
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
    }
L20:
    q[pos] = *i__;
    l[*i__] = pos;
    return 0;
}  
  int_t mc64ed_(int_t *qlen, int_t *n, int_t *q, 
	double *d__, int_t *l, int_t *iway)
{
    int_t i__1;
    int_t i__;
    double di, dk, dr;
    int_t pos, idum, posk;
    --l;
    --d__;
    --q;
    i__ = q[*qlen];
    di = d__[i__];
    --(*qlen);
    pos = 1;
    if (*iway == 1) {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    posk = pos << 1;
	    if (posk > *qlen) {
		goto L20;
	    }
	    dk = d__[q[posk]];
	    if (posk < *qlen) {
		dr = d__[q[posk + 1]];
		if (dk < dr) {
		    ++posk;
		    dk = dr;
		}
	    }
	    if (di >= dk) {
		goto L20;
	    }
	    q[pos] = q[posk];
	    l[q[pos]] = pos;
	    pos = posk;
	}
    } else {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    posk = pos << 1;
	    if (posk > *qlen) {
		goto L20;
	    }
	    dk = d__[q[posk]];
	    if (posk < *qlen) {
		dr = d__[q[posk + 1]];
		if (dk > dr) {
		    ++posk;
		    dk = dr;
		}
	    }
	    if (di <= dk) {
		goto L20;
	    }
	    q[pos] = q[posk];
	    l[q[pos]] = pos;
	    pos = posk;
	}
    }
L20:
    q[pos] = i__;
    l[i__] = pos;
    return 0;
}  
  int_t mc64fd_(int_t *pos0, int_t *qlen, int_t *n, 
	int_t *q, double *d__, int_t *l, int_t *iway)
{
    int_t i__1;
    int_t i__;
    double di, dk, dr;
    int_t qk, pos, idum, posk;
    --l;
    --d__;
    --q;
    if (*qlen == *pos0) {
	--(*qlen);
	return 0;
    }
    i__ = q[*qlen];
    di = d__[i__];
    --(*qlen);
    pos = *pos0;
    if (*iway == 1) {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    if (pos <= 1) {
		goto L20;
	    }
	    posk = pos / 2;
	    qk = q[posk];
	    if (di <= d__[qk]) {
		goto L20;
	    }
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
L20:
	q[pos] = i__;
	l[i__] = pos;
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    posk = pos << 1;
	    if (posk > *qlen) {
		goto L40;
	    }
	    dk = d__[q[posk]];
	    if (posk < *qlen) {
		dr = d__[q[posk + 1]];
		if (dk < dr) {
		    ++posk;
		    dk = dr;
		}
	    }
	    if (di >= dk) {
		goto L40;
	    }
	    qk = q[posk];
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
    } else {
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    if (pos <= 1) {
		goto L34;
	    }
	    posk = pos / 2;
	    qk = q[posk];
	    if (di >= d__[qk]) {
		goto L34;
	    }
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
L34:
	q[pos] = i__;
	l[i__] = pos;
	i__1 = *n;
	for (idum = 1; idum <= i__1; ++idum) {
	    posk = pos << 1;
	    if (posk > *qlen) {
		goto L40;
	    }
	    dk = d__[q[posk]];
	    if (posk < *qlen) {
		dr = d__[q[posk + 1]];
		if (dk > dr) {
		    ++posk;
		    dk = dr;
		}
	    }
	    if (di <= dk) {
		goto L40;
	    }
	    qk = q[posk];
	    q[pos] = qk;
	    l[qk] = pos;
	    pos = posk;
	}
    }
L40:
    q[pos] = i__;
    l[i__] = pos;
    return 0;
}  
  int_t mc64rd_(int_t *n, int_t *ne, int_t *ip, int_t *
	irn, double *a)
{
    int_t i__1, i__2, i__3;
    int_t j, k, r__, s;
    double ha;
    int_t hi, td, mid, len, ipj;
    double key;
    int_t last, todo[50], first;
    --ip;
    --a;
    --irn;
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	len = ip[j + 1] - ip[j];
	if (len <= 1) {
	    goto L100;
	}
	ipj = ip[j];
	if (len < 15) {
	    goto L400;
	}
	todo[0] = ipj;
	todo[1] = ipj + len;
	td = 2;
L500:
	first = todo[td - 2];
	last = todo[td - 1];
	key = a[(first + last) / 2];
	i__2 = last - 1;
	for (k = first; k <= i__2; ++k) {
	    ha = a[k];
	    if (ha == key) {
		goto L475;
	    }
	    if (ha > key) {
		goto L470;
	    }
	    key = ha;
	    goto L470;
L475:
	    ;
	}
	td += -2;
	goto L425;
L470:
	mid = first;
	i__2 = last - 1;
	for (k = first; k <= i__2; ++k) {
	    if (a[k] <= key) {
		goto L450;
	    }
	    ha = a[mid];
	    a[mid] = a[k];
	    a[k] = ha;
	    hi = irn[mid];
	    irn[mid] = irn[k];
	    irn[k] = hi;
	    ++mid;
L450:
	    ;
	}
	if (mid - first >= last - mid) {
	    todo[td + 1] = last;
	    todo[td] = mid;
	    todo[td - 1] = mid;
	} else {
	    todo[td + 1] = mid;
	    todo[td] = first;
	    todo[td - 1] = last;
	    todo[td - 2] = mid;
	}
	td += 2;
L425:
	if (td == 0) {
	    goto L400;
	}
	if (todo[td - 1] - todo[td - 2] >= 15) {
	    goto L500;
	}
	td += -2;
	goto L425;
L400:
	i__2 = ipj + len - 1;
	for (r__ = ipj + 1; r__ <= i__2; ++r__) {
	    if (a[r__ - 1] < a[r__]) {
		ha = a[r__];
		hi = irn[r__];
		a[r__] = a[r__ - 1];
		irn[r__] = irn[r__ - 1];
		i__3 = ipj + 1;
		for (s = r__ - 1; s >= i__3; --s) {
		    if (a[s - 1] < ha) {
			a[s] = a[s - 1];
			irn[s] = irn[s - 1];
		    } else {
			a[s] = ha;
			irn[s] = hi;
			goto L200;
		    }
		}
		a[ipj] = ha;
		irn[ipj] = hi;
	    }
L200:
	    ;
	}
L100:
	;
    }
    return 0;
}  
  int_t mc64sd_(int_t *n, int_t *ne, int_t *ip, int_t *
	irn, double *a, int_t *iperm, int_t *numx, int_t *w, 
	int_t *len, int_t *lenl, int_t *lenh, int_t *fc, int_t *iw, 
	int_t *iw4)
{
    int_t i__1, i__2, i__3, i__4;
    int_t i__, j, k, l, ii, mod, cnt, num;
    double bval, bmin, bmax, rinf;
    int_t nval, wlen, idum1, idum2, idum3;
    extern   int_t mc64qd_(int_t *, int_t *, int_t *, 
	    int_t *, int_t *, double *, int_t *, double *), 
	    mc64ud_(int_t *, int_t *, int_t *, int_t *, int_t *, 
	    int_t *, int_t *, int_t *, int_t *, int_t *, int_t *, 
	    int_t *, int_t *, int_t *, int_t *);
    --iw4;
    --iw;
    --fc;
    --lenh;
    --lenl;
    --len;
    --w;
    --iperm;
    --ip;
    --a;
    --irn;
    rinf = dmach("Overflow");
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	fc[j] = j;
	iw[j] = 0;
	len[j] = ip[j + 1] - ip[j];
    }
    cnt = 1;
    mod = 1;
    *numx = 0;
    mc64ud_(&cnt, &mod, n, &irn[1], ne, &ip[1], &len[1], &fc[1], &iw[1], numx,
	     n, &iw4[1], &iw4[*n + 1], &iw4[(*n << 1) + 1], &iw4[*n * 3 + 1]);
    num = *numx;
    if (num != *n) {
	bmax = rinf;
    } else {
	bmax = rinf;
	i__1 = *n;
	for (j = 1; j <= i__1; ++j) {
	    bval = 0.f;
	    i__2 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__2; ++k) {
		if (a[k] > bval) {
		    bval = a[k];
		}
	    }
	    if (bval < bmax) {
		bmax = bval;
	    }
	}
	bmax *= 1.001f;
    }
    bval = 0.f;
    bmin = 0.f;
    wlen = 0;
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	l = ip[j + 1] - ip[j];
	lenh[j] = l;
	len[j] = l;
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    if (a[k] < bmax) {
		goto L46;
	    }
	}
	k = ip[j + 1];
L46:
	lenl[j] = k - ip[j];
	if (lenl[j] == l) {
	    goto L48;
	}
	++wlen;
	w[wlen] = j;
L48:
	;
    }
    i__1 = *ne;
    for (idum1 = 1; idum1 <= i__1; ++idum1) {
	if (num == *numx) {
	    i__2 = *n;
	    for (i__ = 1; i__ <= i__2; ++i__) {
		iperm[i__] = iw[i__];
	    }
	    i__2 = *ne;
	    for (idum2 = 1; idum2 <= i__2; ++idum2) {
		bmin = bval;
		if (bmax == bmin) {
		    goto L99;
		}
		mc64qd_(&ip[1], &lenl[1], &len[1], &w[1], &wlen, &a[1], &nval,
			 &bval);
		if (nval <= 1) {
		    goto L99;
		}
		k = 1;
		i__3 = *n;
		for (idum3 = 1; idum3 <= i__3; ++idum3) {
		    if (k > wlen) {
			goto L71;
		    }
		    j = w[k];
		    i__4 = ip[j] + lenl[j];
		    for (ii = ip[j] + len[j] - 1; ii >= i__4; --ii) {
			if (a[ii] >= bval) {
			    goto L60;
			}
			i__ = irn[ii];
			if (iw[i__] != j) {
			    goto L55;
			}
			iw[i__] = 0;
			--num;
			fc[*n - num] = j;
L55:
			;
		    }
L60:
		    lenh[j] = len[j];
		    len[j] = ii - ip[j] + 1;
		    if (lenl[j] == lenh[j]) {
			w[k] = w[wlen];
			--wlen;
		    } else {
			++k;
		    }
		}
L71:
		if (num < *numx) {
		    goto L81;
		}
	    }
L81:
	    mod = 1;
	} else {
	    bmax = bval;
	    mc64qd_(&ip[1], &len[1], &lenh[1], &w[1], &wlen, &a[1], &nval, &
		    bval);
	    if (nval == 0 || bval == bmin) {
		goto L99;
	    }
	    k = 1;
	    i__2 = *n;
	    for (idum3 = 1; idum3 <= i__2; ++idum3) {
		if (k > wlen) {
		    goto L88;
		}
		j = w[k];
		i__3 = ip[j] + lenh[j] - 1;
		for (ii = ip[j] + len[j]; ii <= i__3; ++ii) {
		    if (a[ii] < bval) {
			goto L86;
		    }
		}
L86:
		lenl[j] = len[j];
		len[j] = ii - ip[j];
		if (lenl[j] == lenh[j]) {
		    w[k] = w[wlen];
		    --wlen;
		} else {
		    ++k;
		}
	    }
L88:
	    mod = 0;
	}
	++cnt;
	mc64ud_(&cnt, &mod, n, &irn[1], ne, &ip[1], &len[1], &fc[1], &iw[1], &
		num, numx, &iw4[1], &iw4[*n + 1], &iw4[(*n << 1) + 1], &iw4[*
		n * 3 + 1]);
    }
L99:
    if (*numx == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	w[j] = 0;
    }
    k = 0;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (iperm[i__] == 0) {
	    ++k;
	    iw[k] = i__;
	} else {
	    j = iperm[i__];
	    w[j] = i__;
	}
    }
    k = 0;
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	if (w[j] != 0) {
	    goto L320;
	}
	++k;
	idum1 = iw[k];
	iperm[idum1] = j;
L320:
	;
    }
L1000:
    return 0;
}  
  int_t mc64qd_(int_t *ip, int_t *lenl, int_t *lenh, 
	int_t *w, int_t *wlen, double *a, int_t *nval, double *
	val)
{
    int_t i__1, i__2, i__3;
    int_t j, k, s;
    double ha;
    int_t ii, pos;
    double split[10];
    --a;
    --w;
    --lenh;
    --lenl;
    --ip;
    *nval = 0;
    i__1 = *wlen;
    for (k = 1; k <= i__1; ++k) {
	j = w[k];
	i__2 = ip[j] + lenh[j] - 1;
	for (ii = ip[j] + lenl[j]; ii <= i__2; ++ii) {
	    ha = a[ii];
	    if (*nval == 0) {
		split[0] = ha;
		*nval = 1;
	    } else {
		for (s = *nval; s >= 1; --s) {
		    if (split[s - 1] == ha) {
			goto L15;
		    }
		    if (split[s - 1] > ha) {
			pos = s + 1;
			goto L21;
		    }
		}
		pos = 1;
L21:
		i__3 = pos;
		for (s = *nval; s >= i__3; --s) {
		    split[s] = split[s - 1];
		}
		split[pos - 1] = ha;
		++(*nval);
	    }
	    if (*nval == 10) {
		goto L11;
	    }
L15:
	    ;
	}
    }
L11:
    if (*nval > 0) {
	*val = split[(*nval + 1) / 2 - 1];
    }
    return 0;
}  
  int_t mc64ud_(int_t *id, int_t *mod, int_t *n, int_t *
	irn, int_t *lirn, int_t *ip, int_t *lenc, int_t *fc, int_t *
	iperm, int_t *num, int_t *numx, int_t *pr, int_t *arp, 
	int_t *cv, int_t *out)
{
    int_t i__1, i__2, i__3, i__4;
    int_t i__, j, k, j1, ii, kk, id0, id1, in1, in2, nfc, num0, num1, num2, 
	    jord, last;
    --out;
    --cv;
    --arp;
    --pr;
    --iperm;
    --fc;
    --lenc;
    --ip;
    --irn;
    if (*id == 1) {
	i__1 = *n;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    cv[i__] = 0;
	    arp[i__] = 0;
	}
	num1 = *n;
	num2 = *n;
    } else {
	if (*mod == 1) {
	    i__1 = *n;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		arp[i__] = 0;
	    }
	}
	num1 = *numx;
	num2 = *n - *numx;
    }
    num0 = *num;
    nfc = 0;
    id0 = (*id - 1) * *n;
    i__1 = *n;
    for (jord = num0 + 1; jord <= i__1; ++jord) {
	id1 = id0 + jord;
	j = fc[jord - num0];
	pr[j] = -1;
	i__2 = jord;
	for (k = 1; k <= i__2; ++k) {
	    if (arp[j] >= lenc[j]) {
		goto L30;
	    }
	    in1 = ip[j] + arp[j];
	    in2 = ip[j] + lenc[j] - 1;
	    i__3 = in2;
	    for (ii = in1; ii <= i__3; ++ii) {
		i__ = irn[ii];
		if (iperm[i__] == 0) {
		    goto L80;
		}
	    }
	    arp[j] = lenc[j];
L30:
	    out[j] = lenc[j] - 1;
	    i__3 = jord;
	    for (kk = 1; kk <= i__3; ++kk) {
		in1 = out[j];
		if (in1 < 0) {
		    goto L50;
		}
		in2 = ip[j] + lenc[j] - 1;
		in1 = in2 - in1;
		i__4 = in2;
		for (ii = in1; ii <= i__4; ++ii) {
		    i__ = irn[ii];
		    if (cv[i__] == id1) {
			goto L40;
		    }
		    j1 = j;
		    j = iperm[i__];
		    cv[i__] = id1;
		    pr[j] = j1;
		    out[j1] = in2 - ii - 1;
		    goto L70;
L40:
		    ;
		}
L50:
		j1 = pr[j];
		if (j1 == -1) {
		    ++nfc;
		    fc[nfc] = j;
		    if (nfc > num2) {
			last = jord;
			goto L101;
		    }
		    goto L100;
		}
		j = j1;
	    }
L70:
	    ;
	}
L80:
	iperm[i__] = j;
	arp[j] = ii - ip[j] + 1;
	++(*num);
	i__2 = jord;
	for (k = 1; k <= i__2; ++k) {
	    j = pr[j];
	    if (j == -1) {
		goto L95;
	    }
	    ii = ip[j] + lenc[j] - out[j] - 2;
	    i__ = irn[ii];
	    iperm[i__] = j;
	}
L95:
	if (*num == num1) {
	    last = jord;
	    goto L101;
	}
L100:
	;
    }
    last = *n;
L101:
    i__1 = *n;
    for (jord = last + 1; jord <= i__1; ++jord) {
	++nfc;
	fc[nfc] = fc[jord - num0];
    }
    return 0;
}  
  int_t mc64wd_(int_t *n, int_t *ne, int_t *ip, int_t *
	irn, double *a, int_t *iperm, int_t *num, int_t *jperm, 
	int_t *out, int_t *pr, int_t *q, int_t *l, double *u, 
	double *d__)
{
    int_t i__1, i__2, i__3, c__2 = 2;
    int_t i__, j, k, i0, k0, k1, k2, q0;
    double di;
    int_t ii, jj, kk;
    double vj;
    int_t up;
    double dq0;
    int_t kk1, kk2;
    double csp;
    int_t isp, jsp, low;
    double dmin__, dnew;
    int_t jord, qlen, jdum;
    double rinf;
    extern   int_t mc64dd_(int_t *, int_t *, int_t *, 
	    double *, int_t *, int_t *), mc64ed_(int_t *, int_t *,
	     int_t *, double *, int_t *, int_t *), mc64fd_(int_t *
	    , int_t *, int_t *, int_t *, double *, int_t *, 
	    int_t *);
    --d__;
    --u;
    --l;
    --q;
    --pr;
    --out;
    --jperm;
    --iperm;
    --ip;
    --a;
    --irn;
    rinf = dmach("Overflow");
    *num = 0;
    i__1 = *n;
    for (k = 1; k <= i__1; ++k) {
	u[k] = rinf;
	d__[k] = 0.;
	iperm[k] = 0;
	jperm[k] = 0;
	pr[k] = ip[k];
	l[k] = 0;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    i__ = irn[k];
	    if (a[k] > u[i__]) {
		goto L20;
	    }
	    u[i__] = a[k];
	    iperm[i__] = j;
	    l[i__] = k;
L20:
	    ;
	}
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	j = iperm[i__];
	if (j == 0) {
	    goto L40;
	}
	iperm[i__] = 0;
	if (jperm[j] != 0) {
	    goto L40;
	}
	++(*num);
	iperm[i__] = j;
	jperm[j] = l[i__];
L40:
	;
    }
    if (*num == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	if (jperm[j] != 0) {
	    goto L95;
	}
	k1 = ip[j];
	k2 = ip[j + 1] - 1;
	if (k1 > k2) {
	    goto L95;
	}
	vj = rinf;
	i__2 = k2;
	for (k = k1; k <= i__2; ++k) {
	    i__ = irn[k];
	    di = a[k] - u[i__];
	    if (di > vj) {
		goto L50;
	    }
	    if (di < vj || di == rinf) {
		goto L55;
	    }
	    if (iperm[i__] != 0 || iperm[i0] == 0) {
		goto L50;
	    }
L55:
	    vj = di;
	    i0 = i__;
	    k0 = k;
L50:
	    ;
	}
	d__[j] = vj;
	k = k0;
	i__ = i0;
	if (iperm[i__] == 0) {
	    goto L90;
	}
	i__2 = k2;
	for (k = k0; k <= i__2; ++k) {
	    i__ = irn[k];
	    if (a[k] - u[i__] > vj) {
		goto L60;
	    }
	    jj = iperm[i__];
	    kk1 = pr[jj];
	    kk2 = ip[jj + 1] - 1;
	    if (kk1 > kk2) {
		goto L60;
	    }
	    i__3 = kk2;
	    for (kk = kk1; kk <= i__3; ++kk) {
		ii = irn[kk];
		if (iperm[ii] > 0) {
		    goto L70;
		}
		if (a[kk] - u[ii] <= d__[jj]) {
		    goto L80;
		}
L70:
		;
	    }
	    pr[jj] = kk2 + 1;
L60:
	    ;
	}
	goto L95;
L80:
	jperm[jj] = kk;
	iperm[ii] = jj;
	pr[jj] = kk + 1;
L90:
	++(*num);
	jperm[j] = k;
	iperm[i__] = j;
	pr[j] = k + 1;
L95:
	;
    }
    if (*num == *n) {
	goto L1000;
    }
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	d__[i__] = rinf;
	l[i__] = 0;
    }
    i__1 = *n;
    for (jord = 1; jord <= i__1; ++jord) {
	if (jperm[jord] != 0) {
	    goto L100;
	}
	dmin__ = rinf;
	qlen = 0;
	low = *n + 1;
	up = *n + 1;
	csp = rinf;
	j = jord;
	pr[j] = -1;
	i__2 = ip[j + 1] - 1;
	for (k = ip[j]; k <= i__2; ++k) {
	    i__ = irn[k];
	    dnew = a[k] - u[i__];
	    if (dnew >= csp) {
		goto L115;
	    }
	    if (iperm[i__] == 0) {
		csp = dnew;
		isp = k;
		jsp = j;
	    } else {
		if (dnew < dmin__) {
		    dmin__ = dnew;
		}
		d__[i__] = dnew;
		++qlen;
		q[qlen] = k;
	    }
L115:
	    ;
	}
	q0 = qlen;
	qlen = 0;
	i__2 = q0;
	for (kk = 1; kk <= i__2; ++kk) {
	    k = q[kk];
	    i__ = irn[k];
	    if (csp <= d__[i__]) {
		d__[i__] = rinf;
		goto L120;
	    }
	    if (d__[i__] <= dmin__) {
		--low;
		q[low] = i__;
		l[i__] = low;
	    } else {
		++qlen;
		l[i__] = qlen;
		mc64dd_(&i__, n, &q[1], &d__[1], &l[1], &c__2);
	    }
	    jj = iperm[i__];
	    out[jj] = k;
	    pr[jj] = j;
L120:
	    ;
	}
	i__2 = *num;
	for (jdum = 1; jdum <= i__2; ++jdum) {
	    if (low == up) {
		if (qlen == 0) {
		    goto L160;
		}
		i__ = q[1];
		if (d__[i__] >= csp) {
		    goto L160;
		}
		dmin__ = d__[i__];
L152:
		mc64ed_(&qlen, n, &q[1], &d__[1], &l[1], &c__2);
		--low;
		q[low] = i__;
		l[i__] = low;
		if (qlen == 0) {
		    goto L153;
		}
		i__ = q[1];
		if (d__[i__] > dmin__) {
		    goto L153;
		}
		goto L152;
	    }
L153:
	    q0 = q[up - 1];
	    dq0 = d__[q0];
	    if (dq0 >= csp) {
		goto L160;
	    }
	    --up;
	    j = iperm[q0];
	    vj = dq0 - a[jperm[j]] + u[q0];
	    i__3 = ip[j + 1] - 1;
	    for (k = ip[j]; k <= i__3; ++k) {
		i__ = irn[k];
		if (l[i__] >= up) {
		    goto L155;
		}
		dnew = vj + a[k] - u[i__];
		if (dnew >= csp) {
		    goto L155;
		}
		if (iperm[i__] == 0) {
		    csp = dnew;
		    isp = k;
		    jsp = j;
		} else {
		    di = d__[i__];
		    if (di <= dnew) {
			goto L155;
		    }
		    if (l[i__] >= low) {
			goto L155;
		    }
		    d__[i__] = dnew;
		    if (dnew <= dmin__) {
			if (l[i__] != 0) {
			    mc64fd_(&l[i__], &qlen, n, &q[1], &d__[1], &l[1], 
				    &c__2);
			}
			--low;
			q[low] = i__;
			l[i__] = low;
		    } else {
			if (l[i__] == 0) {
			    ++qlen;
			    l[i__] = qlen;
			}
			mc64dd_(&i__, n, &q[1], &d__[1], &l[1], &c__2);
		    }
		    jj = iperm[i__];
		    out[jj] = k;
		    pr[jj] = j;
		}
L155:
		;
	    }
	}
L160:
	if (csp == rinf) {
	    goto L190;
	}
	++(*num);
	i__ = irn[isp];
	iperm[i__] = jsp;
	jperm[jsp] = isp;
	j = jsp;
	i__2 = *num;
	for (jdum = 1; jdum <= i__2; ++jdum) {
	    jj = pr[j];
	    if (jj == -1) {
		goto L180;
	    }
	    k = out[j];
	    i__ = irn[k];
	    iperm[i__] = jj;
	    jperm[jj] = k;
	    j = jj;
	}
L180:
	i__2 = *n;
	for (kk = up; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    u[i__] = u[i__] + d__[i__] - csp;
	}
L190:
	i__2 = *n;
	for (kk = low; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    d__[i__] = rinf;
	    l[i__] = 0;
	}
	i__2 = qlen;
	for (kk = 1; kk <= i__2; ++kk) {
	    i__ = q[kk];
	    d__[i__] = rinf;
	    l[i__] = 0;
	}
L100:
	;
    }
L1000:
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	k = jperm[j];
	if (k != 0) {
	    d__[j] = a[k] - u[irn[k]];
	} else {
	    d__[j] = 0.;
	}
	if (iperm[j] == 0) {
	    u[j] = 0.;
	}
    }
    if (*num == *n) {
	goto L1100;
    }
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	jperm[j] = 0;
    }
    k = 0;
    i__1 = *n;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (iperm[i__] == 0) {
	    ++k;
	    out[k] = i__;
	} else {
	    j = iperm[i__];
	    jperm[j] = i__;
	}
    }
    k = 0;
    i__1 = *n;
    for (j = 1; j <= i__1; ++j) {
	if (jperm[j] != 0) {
	    goto L320;
	}
	++k;
	jdum = out[k];
	iperm[jdum] = j;
L320:
	;
    }
L1100:
    return 0;
}  