#ifndef __SUPERLU_DCOMPLEX  
#define __SUPERLU_DCOMPLEX
#ifndef DCOMPLEX_INCLUDE
#define DCOMPLEX_INCLUDE
typedef struct { double r, i; } doublecomplex;
#define z_add(c, a, b) { (c)->r = (a)->r + (b)->r; \
			 (c)->i = (a)->i + (b)->i; }
#define z_sub(c, a, b) { (c)->r = (a)->r - (b)->r; \
			 (c)->i = (a)->i - (b)->i; }
#define zd_mult(c, a, b) { (c)->r = (a)->r * (b); \
                           (c)->i = (a)->i * (b); }
#define zz_mult(c, a, b) { \
	double cr, ci; \
    	cr = (a)->r * (b)->r - (a)->i * (b)->i; \
    	ci = (a)->i * (b)->r + (a)->r * (b)->i; \
    	(c)->r = cr; \
    	(c)->i = ci; \
    }
#define zz_conj(a, b) { \
        (a)->r = (b)->r; \
        (a)->i = -((b)->i); \
    }
#define z_eq(a, b)  ( (a)->r == (b)->r && (a)->i == (b)->i )
#ifdef __cplusplus
extern "C" {
#endif
void z_div(doublecomplex *, doublecomplex *, doublecomplex *);
double z_abs(doublecomplex *);      
double z_abs1(doublecomplex *);     
void z_exp(doublecomplex *, doublecomplex *);
void d_cnjg(doublecomplex *r, doublecomplex *z);
double d_imag(doublecomplex *);
doublecomplex z_sgn(doublecomplex *);
doublecomplex z_sqrt(doublecomplex *);
#ifdef __cplusplus
  }
#endif
#endif
#endif   