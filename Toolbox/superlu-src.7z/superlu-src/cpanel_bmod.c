#include <stdio.h>
#include <stdlib.h>
#include "slu_cdefs.h"
void clsolve(int, int, complex *, complex *);
void cmatvec(int, int, int, complex *, complex *, complex *);
extern void ccheck_tempv();
void
cpanel_bmod (
	    const int  m,           
	    const int  w,           
	    const int  jcol,        
	    const int  nseg,        
	    complex     *dense,      
	    complex     *tempv,      
	    int        *segrep,     
	    int        *repfnz,     
	    GlobalLU_t *Glu,        
	    SuperLUStat_t *stat     
	    )
{
#ifdef USE_VENDOR_BLAS
#ifdef _CRAY
    _fcd ftcs1 = _cptofcd("L", strlen("L")),
         ftcs2 = _cptofcd("N", strlen("N")),
         ftcs3 = _cptofcd("U", strlen("U"));
#endif
    int          incx = 1, incy = 1;
    complex       alpha, beta;
#endif
    register int k, ksub;
    int          fsupc, nsupc, nsupr, nrow;
    int          krep, krep_ind;
    complex       ukj, ukj1, ukj2;
    int          luptr, luptr1, luptr2;
    int          segsze;
    int          block_nrow;   
    register int lptr;	       
    int          kfnz, irow, no_zeros; 
    register int isub, isub1, i;
    register int jj;	       
    int          *xsup, *supno;
    int          *lsub, *xlsub;
    complex       *lusup;
    int          *xlusup;
    int          *repfnz_col;  
    complex       *dense_col;   
    complex       *tempv1;              
    complex       *TriTmp, *MatvecTmp;  
    complex      zero = {0.0, 0.0};
    complex      one = {1.0, 0.0};
    complex      comp_temp, comp_temp1;
    register int ldaTmp;
    register int r_ind, r_hi;
    int  maxsuper, rowblk, colblk;
    flops_t  *ops = stat->ops;
    xsup    = Glu->xsup;
    supno   = Glu->supno;
    lsub    = Glu->lsub;
    xlsub   = Glu->xlsub;
    lusup   = (complex *) Glu->lusup;
    xlusup  = Glu->xlusup;
    maxsuper = SUPERLU_MAX( sp_ienv(3), sp_ienv(7) );
    rowblk   = sp_ienv(4);
    colblk   = sp_ienv(5);
    ldaTmp   = maxsuper + rowblk;
    k = nseg - 1;
    for (ksub = 0; ksub < nseg; ksub++) {  
        krep = segrep[k--];
	fsupc = xsup[supno[krep]];
	nsupc = krep - fsupc + 1;
	nsupr = xlsub[fsupc+1] - xlsub[fsupc];
	nrow = nsupr - nsupc;
	lptr = xlsub[fsupc];
	krep_ind = lptr + nsupc - 1;
	repfnz_col = repfnz;
	dense_col = dense;
	if ( nsupc >= colblk && nrow > rowblk ) {  
	    TriTmp = tempv;
	    for (jj = jcol; jj < jcol + w; jj++,
		 repfnz_col += m, dense_col += m, TriTmp += ldaTmp ) {
		kfnz = repfnz_col[krep];
		if ( kfnz == EMPTY ) continue;	 
		segsze = krep - kfnz + 1;
		luptr = xlusup[fsupc];
		ops[TRSV] += 4 * segsze * (segsze - 1);
		ops[GEMV] += 8 * nrow * segsze;
		if ( segsze == 1 ) {
		    ukj = dense_col[lsub[krep_ind]];
		    luptr += nsupr*(nsupc-1) + nsupc;
		    for (i = lptr + nsupc; i < xlsub[fsupc+1]; i++) {
			irow = lsub[i];
	    	        cc_mult(&comp_temp, &ukj, &lusup[luptr]);
		        c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			++luptr;
		    }
		} else if ( segsze <= 3 ) {
		    ukj = dense_col[lsub[krep_ind]];
		    ukj1 = dense_col[lsub[krep_ind - 1]];
		    luptr += nsupr*(nsupc-1) + nsupc-1;
		    luptr1 = luptr - nsupr;
		    if ( segsze == 2 ) {
		        cc_mult(&comp_temp, &ukj1, &lusup[luptr1]);
		        c_sub(&ukj, &ukj, &comp_temp);
			dense_col[lsub[krep_ind]] = ukj;
			for (i = lptr + nsupc; i < xlsub[fsupc+1]; ++i) {
			    irow = lsub[i];
			    luptr++; luptr1++;
			    cc_mult(&comp_temp, &ukj, &lusup[luptr]);
			    cc_mult(&comp_temp1, &ukj1, &lusup[luptr1]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			}
		    } else {
			ukj2 = dense_col[lsub[krep_ind - 2]];
			luptr2 = luptr1 - nsupr;
  		        cc_mult(&comp_temp, &ukj2, &lusup[luptr2-1]);
		        c_sub(&ukj1, &ukj1, &comp_temp);
		        cc_mult(&comp_temp, &ukj1, &lusup[luptr1]);
        		cc_mult(&comp_temp1, &ukj2, &lusup[luptr2]);
		        c_add(&comp_temp, &comp_temp, &comp_temp1);
		        c_sub(&ukj, &ukj, &comp_temp);
			dense_col[lsub[krep_ind]] = ukj;
			dense_col[lsub[krep_ind-1]] = ukj1;
			for (i = lptr + nsupc; i < xlsub[fsupc+1]; ++i) {
			    irow = lsub[i];
			    luptr++; luptr1++; luptr2++;
			    cc_mult(&comp_temp, &ukj, &lusup[luptr]);
			    cc_mult(&comp_temp1, &ukj1, &lusup[luptr1]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    cc_mult(&comp_temp1, &ukj2, &lusup[luptr2]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			}
		    }
		} else  {	 
		    no_zeros = kfnz - fsupc;
		    isub = lptr + no_zeros;
		    for (i = 0; i < segsze; ++i) {
			irow = lsub[isub];
			TriTmp[i] = dense_col[irow];  
			++isub;
		    }
		    luptr += nsupr * no_zeros + no_zeros;
#ifdef USE_VENDOR_BLAS
#ifdef _CRAY
		    CTRSV( ftcs1, ftcs2, ftcs3, &segsze, &lusup[luptr], 
			   &nsupr, TriTmp, &incx );
#else
		    ctrsv_( "L", "N", "U", &segsze, &lusup[luptr], 
			   &nsupr, TriTmp, &incx );
#endif
#else		
		    clsolve ( nsupr, segsze, &lusup[luptr], TriTmp );
#endif
		}  
	    }   
	    for ( r_ind = 0; r_ind < nrow; r_ind += rowblk ) {
		r_hi = SUPERLU_MIN(nrow, r_ind + rowblk);
		block_nrow = SUPERLU_MIN(rowblk, r_hi - r_ind);
		luptr = xlusup[fsupc] + nsupc + r_ind;
		isub1 = lptr + nsupc + r_ind;
		repfnz_col = repfnz;
		TriTmp = tempv;
		dense_col = dense;
		for (jj = jcol; jj < jcol + w; jj++,
		     repfnz_col += m, dense_col += m, TriTmp += ldaTmp) {
		    kfnz = repfnz_col[krep];
		    if ( kfnz == EMPTY ) continue;  
		    segsze = krep - kfnz + 1;
		    if ( segsze <= 3 ) continue;    
		    no_zeros = kfnz - fsupc;
		    luptr1 = luptr + nsupr * no_zeros;
		    MatvecTmp = &TriTmp[maxsuper];
#ifdef USE_VENDOR_BLAS
		    alpha = one; 
                    beta = zero;
#ifdef _CRAY
		    CGEMV(ftcs2, &block_nrow, &segsze, &alpha, &lusup[luptr1], 
			   &nsupr, TriTmp, &incx, &beta, MatvecTmp, &incy);
#else
		    cgemv_("N", &block_nrow, &segsze, &alpha, &lusup[luptr1], 
			   &nsupr, TriTmp, &incx, &beta, MatvecTmp, &incy);
#endif
#else
		    cmatvec(nsupr, block_nrow, segsze, &lusup[luptr1],
			   TriTmp, MatvecTmp);
#endif
		    isub = isub1;
		    for (i = 0; i < block_nrow; i++) {
			irow = lsub[isub];
		        c_sub(&dense_col[irow], &dense_col[irow], 
                              &MatvecTmp[i]);
			MatvecTmp[i] = zero;
			++isub;
		    }
		}  
	    }  
	    repfnz_col = repfnz;
	    TriTmp = tempv;
	    dense_col = dense;
	    for (jj = jcol; jj < jcol + w; jj++,
		 repfnz_col += m, dense_col += m, TriTmp += ldaTmp) {
		kfnz = repfnz_col[krep];
		if ( kfnz == EMPTY ) continue;  
		segsze = krep - kfnz + 1;
		if ( segsze <= 3 ) continue;  
		no_zeros = kfnz - fsupc;		
		isub = lptr + no_zeros;
		for (i = 0; i < segsze; i++) {
		    irow = lsub[isub];
		    dense_col[irow] = TriTmp[i];
		    TriTmp[i] = zero;
		    ++isub;
		}
	    }  
	} else {  
	    for (jj = jcol; jj < jcol + w; jj++,
		 repfnz_col += m, dense_col += m) {
		kfnz = repfnz_col[krep];
		if ( kfnz == EMPTY ) continue;	 
		segsze = krep - kfnz + 1;
		luptr = xlusup[fsupc];
		ops[TRSV] += 4 * segsze * (segsze - 1);
		ops[GEMV] += 8 * nrow * segsze;
		if ( segsze == 1 ) {
		    ukj = dense_col[lsub[krep_ind]];
		    luptr += nsupr*(nsupc-1) + nsupc;
		    for (i = lptr + nsupc; i < xlsub[fsupc+1]; i++) {
			irow = lsub[i];
	    	        cc_mult(&comp_temp, &ukj, &lusup[luptr]);
		        c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			++luptr;
		    }
		} else if ( segsze <= 3 ) {
		    ukj = dense_col[lsub[krep_ind]];
		    luptr += nsupr*(nsupc-1) + nsupc-1;
		    ukj1 = dense_col[lsub[krep_ind - 1]];
		    luptr1 = luptr - nsupr;
		    if ( segsze == 2 ) {
		        cc_mult(&comp_temp, &ukj1, &lusup[luptr1]);
		        c_sub(&ukj, &ukj, &comp_temp);
			dense_col[lsub[krep_ind]] = ukj;
			for (i = lptr + nsupc; i < xlsub[fsupc+1]; ++i) {
			    irow = lsub[i];
			    ++luptr;  ++luptr1;
			    cc_mult(&comp_temp, &ukj, &lusup[luptr]);
			    cc_mult(&comp_temp1, &ukj1, &lusup[luptr1]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			}
		    } else {
			ukj2 = dense_col[lsub[krep_ind - 2]];
			luptr2 = luptr1 - nsupr;
  		        cc_mult(&comp_temp, &ukj2, &lusup[luptr2-1]);
		        c_sub(&ukj1, &ukj1, &comp_temp);
		        cc_mult(&comp_temp, &ukj1, &lusup[luptr1]);
        		cc_mult(&comp_temp1, &ukj2, &lusup[luptr2]);
		        c_add(&comp_temp, &comp_temp, &comp_temp1);
		        c_sub(&ukj, &ukj, &comp_temp);
			dense_col[lsub[krep_ind]] = ukj;
			dense_col[lsub[krep_ind-1]] = ukj1;
			for (i = lptr + nsupc; i < xlsub[fsupc+1]; ++i) {
			    irow = lsub[i];
			    ++luptr; ++luptr1; ++luptr2;
			    cc_mult(&comp_temp, &ukj, &lusup[luptr]);
			    cc_mult(&comp_temp1, &ukj1, &lusup[luptr1]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    cc_mult(&comp_temp1, &ukj2, &lusup[luptr2]);
			    c_add(&comp_temp, &comp_temp, &comp_temp1);
			    c_sub(&dense_col[irow], &dense_col[irow], &comp_temp);
			}
		    }
		} else  {  
		    no_zeros = kfnz - fsupc;
		    isub = lptr + no_zeros;
		    for (i = 0; i < segsze; ++i) {
			irow = lsub[isub];
			tempv[i] = dense_col[irow];  
			++isub;
		    }
		    luptr += nsupr * no_zeros + no_zeros;
#ifdef USE_VENDOR_BLAS
#ifdef _CRAY
		    CTRSV( ftcs1, ftcs2, ftcs3, &segsze, &lusup[luptr], 
			   &nsupr, tempv, &incx );
#else
		    ctrsv_( "L", "N", "U", &segsze, &lusup[luptr], 
			   &nsupr, tempv, &incx );
#endif
		    luptr += segsze;	 
		    tempv1 = &tempv[segsze];
                    alpha = one;
                    beta = zero;
#ifdef _CRAY
		    CGEMV( ftcs2, &nrow, &segsze, &alpha, &lusup[luptr], 
			   &nsupr, tempv, &incx, &beta, tempv1, &incy );
#else
		    cgemv_( "N", &nrow, &segsze, &alpha, &lusup[luptr], 
			   &nsupr, tempv, &incx, &beta, tempv1, &incy );
#endif
#else
		    clsolve ( nsupr, segsze, &lusup[luptr], tempv );
		    luptr += segsze;         
		    tempv1 = &tempv[segsze];
		    cmatvec (nsupr, nrow, segsze, &lusup[luptr], tempv, tempv1);
#endif
		    isub = lptr + no_zeros;
		    for (i = 0; i < segsze; i++) {
			irow = lsub[isub];
			dense_col[irow] = tempv[i];
			tempv[i] = zero;
			isub++;
		    }
		    for (i = 0; i < nrow; i++) {
			irow = lsub[isub];
		        c_sub(&dense_col[irow], &dense_col[irow], &tempv1[i]);
			tempv1[i] = zero;
			++isub;	
		    }
		}  
	    }  
	}  
    }  
}