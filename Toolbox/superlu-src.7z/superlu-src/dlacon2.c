#include <math.h>
#include "slu_Cnames.h"
int
dlacon2_(int *n, double *v, double *x, int *isgn, double *est, int *kase, int isave[3])
{
    int c__1 = 1;
    double      zero = 0.0;
    double      one = 1.0;
    int jlast;
    double altsgn, estold;
    int i;
    double temp;
#ifdef _CRAY
    extern int ISAMAX(int *, double *, int *);
    extern double SASUM(int *, double *, int *);
    extern int SCOPY(int *, double *, int *, double *, int *);
#else
    extern int idamax_(int *, double *, int *);
    extern double dasum_(int *, double *, int *);
    extern int dcopy_(int *, double *, int *, double *, int *);
#endif
#define d_sign(a, b) (b >= 0 ? fabs(a) : -fabs(a))     
#define i_dnnt(a) \
	( a>=0 ? floor(a+.5) : -floor(.5-a) )  
    if ( *kase == 0 ) {
	for (i = 0; i < *n; ++i) {
	    x[i] = 1. / (double) (*n);
	}
	*kase = 1;
	isave[0] = 1;	 
	return 0;
    }
    switch (isave[0]) {
	case 1:  goto L20;
	case 2:  goto L40;
	case 3:  goto L70;
	case 4:  goto L110;
	case 5:  goto L140;
    }
  L20:
    if (*n == 1) {
	v[0] = x[0];
	*est = fabs(v[0]);
	goto L150;
    }
#ifdef _CRAY
    *est = SASUM(n, x, &c__1);
#else
    *est = dasum_(n, x, &c__1);
#endif
    for (i = 0; i < *n; ++i) {
	x[i] = d_sign(one, x[i]);
	isgn[i] = i_dnnt(x[i]);
    }
    *kase = 2;
    isave[0] = 2;   
    return 0;
L40:
#ifdef _CRAY
    isave[1] = ISAMAX(n, &x[0], &c__1);    
#else
    isave[1] = idamax_(n, &x[0], &c__1);   
#endif
    --isave[1];   
    isave[2] = 2;   
L50:
    for (i = 0; i < *n; ++i) x[i] = zero;
    x[isave[1]] = one;
    *kase = 1;
    isave[0] = 3;   
    return 0;
L70:
#ifdef _CRAY
    SCOPY(n, x, &c__1, v, &c__1);
#else
    dcopy_(n, x, &c__1, v, &c__1);
#endif
    estold = *est;
#ifdef _CRAY
    *est = SASUM(n, v, &c__1);
#else
    *est = dasum_(n, v, &c__1);
#endif
    for (i = 0; i < *n; ++i)
	if (i_dnnt(d_sign(one, x[i])) != isgn[i])
	    goto L90;
    goto L120;
L90:
    if (*est <= estold) goto L120;
    for (i = 0; i < *n; ++i) {
	x[i] = d_sign(one, x[i]);
	isgn[i] = i_dnnt(x[i]);
    }
    *kase = 2;
    isave[0] = 4;   
    return 0;
L110:
    jlast = isave[1];   
#ifdef _CRAY
    isave[1] = ISAMAX(n, &x[0], &c__1);   
#else
    isave[1] = idamax_(n, &x[0], &c__1);   
#endif
    isave[1] = isave[1] - 1;   
    if (x[jlast] != fabs(x[isave[1]]) && isave[2] < 5) {
	isave[2] = isave[2] + 1;   
	goto L50;
    }
L120:
    altsgn = 1.;
    for (i = 1; i <= *n; ++i) {
	x[i-1] = altsgn * ((double)(i - 1) / (double)(*n - 1) + 1.);
	altsgn = -altsgn;
    }
    *kase = 1;
    isave[0] = 5;   
    return 0;
L140:
#ifdef _CRAY
    temp = SASUM(n, x, &c__1) / (double)(*n * 3) * 2.;
#else
    temp = dasum_(n, x, &c__1) / (double)(*n * 3) * 2.;
#endif
    if (temp > *est) {
#ifdef _CRAY
	SCOPY(n, &x[0], &c__1, &v[0], &c__1);
#else
	dcopy_(n, &x[0], &c__1, &v[0], &c__1);
#endif
	*est = temp;
    }
L150:
    *kase = 0;
    return 0;
}  