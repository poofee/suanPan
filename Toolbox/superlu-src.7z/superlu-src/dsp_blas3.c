#include "slu_ddefs.h"
int
sp_dgemm(char *transa, char *transb, int m, int n, int k, 
         double alpha, SuperMatrix *A, double *b, int ldb, 
         double beta, double *c, int ldc)
{
    int    incx = 1, incy = 1;
    int    j;
    for (j = 0; j < n; ++j) {
	sp_dgemv(transa, alpha, A, &b[ldb*j], incx, beta, &c[ldc*j], incy);
    }
    return 0;    
}