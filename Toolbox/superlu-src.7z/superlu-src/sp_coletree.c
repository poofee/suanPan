#include <stdio.h>
#include <stdlib.h>
#include "slu_ddefs.h"
static 
int *mxCallocInt(int n)
{
    register int i;
    int *buf;
    buf = (int *) SUPERLU_MALLOC( n * sizeof(int) );
    if ( !buf ) {
         ABORT("SUPERLU_MALLOC fails for buf in mxCallocInt()");
       }
    for (i = 0; i < n; i++) buf[i] = 0;
    return (buf);
}
static
void initialize_disjoint_sets (
			       int n,
			       int **pp
			       )
{
	(*pp) = mxCallocInt(n);
}
static
int make_set (
	      int i,
	      int *pp
	      )
{
	pp[i] = i;
	return i;
}
static
int link (
	  int s,
	  int t,
	  int *pp
	  )
{
	pp[s] = t;
	return t;
}
static
int find (
	  int i,
	  int *pp
	  )
{
    register int p, gp;
    p = pp[i];
    gp = pp[p];
    while (gp != p) {
	pp[i] = gp;
	i = gp;
	p = pp[i];
	gp = pp[p];
    }
    return (p);
}
#if 0
static
int find (
	int i
	)
{
	if (pp[i] != i) 
		pp[i] = find (pp[i]);
	return pp[i];
}
#endif
static
void finalize_disjoint_sets (
			     int *pp
			     )
{
	SUPERLU_FREE(pp);
}
int
sp_coletree(
	    int *acolst, int *acolend,  
	    int *arow,                  
	    int nr, int nc,             
	    int *parent	                
	    )
{
	int	*root;			 
	int     *firstcol;		 
	int	rset, cset;             
	int	row, col;
	int	rroot;
	int	p;
	int     *pp;
	root = mxCallocInt (nc);
	initialize_disjoint_sets (nc, &pp);
	firstcol = mxCallocInt (nr);
	for (row = 0; row < nr; firstcol[row++] = nc);
	for (col = 0; col < nc; col++) 
		for (p = acolst[col]; p < acolend[col]; p++) {
			row = arow[p];
			firstcol[row] = SUPERLU_MIN(firstcol[row], col);
		}
	for (col = 0; col < nc; col++) {
		cset = make_set (col, pp);
		root[cset] = col;
		parent[col] = nc;  
		for (p = acolst[col]; p < acolend[col]; p++) {
			row = firstcol[arow[p]];
			if (row >= col) continue;
			rset = find (row, pp);
			rroot = root[rset];
			if (rroot != col) {
				parent[rroot] = col;
				cset = link (cset, rset, pp);
				root[cset] = col;
			}
		}
	}
	SUPERLU_FREE (root);
	SUPERLU_FREE (firstcol);
	finalize_disjoint_sets (pp);
	return 0;
}
static
void etdfs (
	    int	  v,
	    int   first_kid[],
	    int   next_kid[],
	    int   post[], 
	    int   *postnum
	    )
{
	int	w;
	for (w = first_kid[v]; w != -1; w = next_kid[w]) {
		etdfs (w, first_kid, next_kid, post, postnum);
	}
	post[v] = (*postnum)++;     
}
static
void nr_etdfs (int n, int *parent,
	       int *first_kid, int *next_kid,
	       int *post, int postnum)
{
    int current = n, first, next;
    while (postnum != n){
        first = first_kid[current];
        if (first == -1){
            post[current] = postnum++;
            next = next_kid[current];
            while (next == -1){
                current = parent[current];
                post[current] = postnum++;
                next = next_kid[current];
	    }
            if (postnum==n+1) return;
            current = next;
        }
        else {
            current = first;
	}
    }
}
int *TreePostorder(
		   int n,
		   int *parent
		   )
{
        int	*first_kid, *next_kid;	 
        int	*post, postnum;
	int	v, dad;
	first_kid = 	mxCallocInt (n+1);
	next_kid  = 	mxCallocInt (n+1);
	post	  = 	mxCallocInt (n+1);
	for (v = 0; v <= n; first_kid[v++] = -1);
	for (v = n-1; v >= 0; v--) {
		dad = parent[v];
		next_kid[v] = first_kid[dad];
		first_kid[dad] = v;
	}
	postnum = 0;
#if 0
	etdfs (n, first_kid, next_kid, post, &postnum);
#else
	nr_etdfs(n, parent, first_kid, next_kid, post, postnum);
#endif
	SUPERLU_FREE (first_kid);
	SUPERLU_FREE (next_kid);
	return post;
}
int
sp_symetree(
	    int *acolst, int *acolend,  
	    int *arow,             
	    int n,                 
	    int *parent	     
	    )
{
	int	*root;		     
	int	rset, cset;             
	int	row, col;
	int	rroot;
	int	p;
	int     *pp;
	root = mxCallocInt (n);
	initialize_disjoint_sets (n, &pp);
	for (col = 0; col < n; col++) {
		cset = make_set (col, pp);
		root[cset] = col;
		parent[col] = n;  
		for (p = acolst[col]; p < acolend[col]; p++) {
			row = arow[p];
			if (row >= col) continue;
			rset = find (row, pp);
			rroot = root[rset];
			if (rroot != col) {
				parent[rroot] = col;
				cset = link (cset, rset, pp);
				root[cset] = col;
			}
		}
	}
	SUPERLU_FREE (root);
	finalize_disjoint_sets (pp);
	return 0;
}  