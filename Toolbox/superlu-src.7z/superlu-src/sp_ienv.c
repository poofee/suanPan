#include "slu_Cnames.h"
int
sp_ienv(int ispec)
{
    int i;
    switch (ispec) {
	case 1: return (20);
	case 2: return (10);
	case 3: return (200);
	case 4: return (200);
	case 5: return (100);
        case 6: return (30);
        case 7: return (10);
    }
    i = 1;
    input_error("sp_ienv", &i);
    return 0;
}  