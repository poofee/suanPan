#if !(defined MPL_MESSAGE_HPP)

#define MPL_MESSAGE_HPP

#include <mpi.h>

namespace mpl {

typedef MPI_Message message;
}

#endif
